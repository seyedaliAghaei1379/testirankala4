<?php

class FactorAppendUpdate
{
    var $FactorInfo;
    var $RizFactorInfo;
    var $DaryaftiInfo;
    var $RizEzafatKosoorat;
}

class FactorAppendWithPerson
{
    var $PersonInfo;
    var $FactorInfo;
    var $RizFactorInfo;
    var $DaryaftiInfo;
    var $RizEzafatKosoorat;
}

class RizEzafatKosooratClass{
    var $Ft;
    var $BedBes;
    var $SatrNum;
    var $EzafKosoorCode;
    var $Darsad;
    var $Mablagh;
    var $MabKol;
}

class DaryaftiInfoClass{
    var $DayDate;
    var $BankCode;
    var $HavaleNum;
    var $HavalePrice;
    var $DepC;
    var $KCode;
}

class RizFactorInfoClass
{
    var $Ft;
    var $SatrNum;
    var $BedBes;
    var $AnbarCode;
    var $KSPC;
    var $Sharh;
    var $TV1;
    var $Fi;
    var $MabK;
    var $DT;
    var $TMab;
    var $TV2Ex;
    var $Z1;
    var $Z2;
    var $Z3;
    var $RizSID;
    var $NDate;
    var $KalaPCode;
}

class FactorInfoClass
{
    var $NewFt;
    var $Pc;
    var $Dd;
    var $Sharh;
    var $FPrice;
    var $Naghd;
    var $Aghsat;
    var $Takhfif;
    var $Nesieh;
    var $Havale;
    var $BedBes;
    var $Ezafat;
    var $Kosoorat;
    var $VizitorCode;
    var $SaveTime;
    var $SumMaliat;
    var $SumTakhfifSatr;
    var $KCode;
    var $Inf;
    var $PfNum;
    var $TasvieT;
    var $PAddr;
    var $PTel;
    var $SumAvarez;
    var $DepC;
    var $DepN;
    var $Bon;
    var $IsOk;
    var $IsCancel;
}

class FactorInfoWithPersonClass
{
    var $NewFt;
    var $Dd;
    var $Sharh;
    var $FPrice;
    var $Naghd;
    var $Aghsat;
    var $Takhfif;
    var $Nesieh;
    var $Havale;
    var $BedBes;
    var $Ezafat;
    var $Kosoorat;
    var $VizitorCode;
    var $SaveTime;
    var $SumMaliat;
    var $SumTakhfifSatr;
    var $KCode;
    var $Inf;
    var $PfNum;
    var $TasvieT;
    var $PAddr;
    var $PTel;
    var $SumAvarez;
    var $DepC;
    var $DepN;
    var $Bon;
    var $IsOk;
    var $IsCancel;
}

class PersonInfoClass
{
    var $OpMode;
    var $Code;
    var $ACode;
    var $FCode;
    var $Name;
    var $Family;
    var $MelliCode;
    var $Tel;
    var $Mobile;
    var $Address;
    var $BirthDay;
    var $PostCode;
    var $Info;
    var $PersonType;
    var $Email;
    var $NameFamily2;
    var $ShomareHesab;
    var $Tel2;
    var $Tel3;
    var $ECode;
    var $Fax;
    var $FatherName;
    var $ShNum;
}

?>