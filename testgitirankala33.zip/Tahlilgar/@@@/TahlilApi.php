<?php

/**
 * Plugin Name: TahlilApi
 * Plugin URI: http://sarayeiranishop.com/
 * Description: Tahlil Web Service.
 * Version: 1.0.0
 * Author: hossein moradi
 * Author URI: https://sarayeiranishop.com/
 * License: GPL2
 */
defined('ABSPATH') or die('Plugin file cannot be accessed directly.');

include 'inc/Constants.inc.php';
include 'TahlilAdmin.php';
include 'inc/Classes.inc.php';

/**
 * Check if WooCommerce is active
 * */
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    // Put your plugin code here

    add_action('woocommerce_loaded', function () {

        //Check if TahlilApi Class is exists 
        if (!class_exists('TahlilApi')) {

            class TahlilApi {

                const TableName = _TABLENAME;
                const GroupMapTable = _APIGROUPMAP;

                public function __construct() {
                    global $apiHandler;
                    require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );

                    //echo $apiHandler->GetKalaList1(get_option('tahlil_ip_port').get_option('tahlil_api_address'),get_option('tahlil_api_pass'),get_option('tahlil_params') );
                    //Create Log Table
                    //echo rand(1000000, 9999999)."<br/><br/><br/>";
                    //echo "sssfffffffffffffffffffffffffffffffffffffffffffffffffffffff";
                    $this->db_install();
                }

                public function update_product($product_id, $_price, $_quantity, $_sku, $_gcode) {
                    global $wpdb;
                    $ecd_product = new WC_Product($product_id);
                    /**
                     * Check if product exists
                     */
                    if ($ecd_product->exists()) {
                        /**
                         * Get current (discounted) sales price for calculations etc
                         */
                        $sale_price = $ecd_product->sale_price;
                        /**
                         * Get regular price for calculations etc
                         */
                        $regular_price = $ecd_product->regular_price;
                        /**
                         * Get price (the actually price that people will pay)
                         * NOTE: If you set sales price different, this should be same as sales price
                         */
                        $price = $ecd_product->price;
                        /**
                         * Update sales price
                         */
                        //$rp = update_post_meta($ecd_product->id, '_regular_price', '1000');
                        $sp = update_post_meta($ecd_product->id, '_sale_price', $_price);
                        $p = update_post_meta($ecd_product->id, '_price', $_price);
                        $ms = update_post_meta($ecd_product->id, '_manage_stock', 'yes');
                        $q = update_post_meta($ecd_product->id, '_stock', $_quantity);
                        $sku = update_post_meta($ecd_product->id, '_sku', $_sku);


                        $term = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . _APIGROUPMAP . " WHERE kalacode LIKE'%" . $_gcode . "%'");

                        if ($term !== null) {
                            foreach ($term as $k => $v) {
                                $term_rel = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "term_relationships WHERE object_id=" . $ecd_product->id . " AND term_taxonomy_id=" . $v->term_id);

                                if ($term_rel === null) {
                                    $sql = " INSERT INTO " . $wpdb->prefix . "term_relationships (object_id,term_taxonomy_id,term_order) values (" . $ecd_product->id . "," . $v->term_id . ", 0)";

                                    $wpdb->query($sql);
                                }
                            }
                        }
                    }
                }

                public function UpdateOrder($order_id,$order_params){
                    global $wpdb;
                    
                    //echo $order_params;
                    
                    $term = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . _APIORDERS . " WHERE order_id=" . $order_id);

                    if ($term === null) {
                        $sql = " INSERT INTO " . $wpdb->prefix . _APIORDERS . " (order_id,order_params,order_status) values (" . $order_id . ",'" . $order_params . "', '')";

                        $wpdb->query($sql);
                    } else {
                        $sql = " UPDATE " . $wpdb->prefix . _APIORDERS . " SET order_params = '" . $order_params . "' WHERE order_id=" . $order_id;

                        $wpdb->query($sql);
                    }
                }
                
                public function UpdateOrderStatus($order_id,$status){
                    global $wpdb;
                    
                    $sql = " UPDATE " . $wpdb->prefix . _APIORDERS . " SET order_status = '" . $status . "' WHERE order_id=" . $order_id;
                    $wpdb->query($sql);
                }
                
                public function getOrder($order_id){
                    global $wpdb;
                    return $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . _APIORDERS . " WHERE order_id=" . $order_id);
                }
                
                public function SendOrders() {
                    global $wpdb;
                    global $apiHandler;
                    
                    $res = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . _APIORDERS . " WHERE (1=1)");
                    
                    foreach ($res as $row)
                    {
                        $status = json_decode($row->order_status);
                        
                        if(trim($row->order_status)==""){
                            $r = $apiHandler->Send(get_option('tahlil_ip_port') . "api/FactorAppendWithPerson", get_option('tahlil_api_pass'), $row->order_params);
                            $this->UpdateOrderStatus($row->order_id, json_encode($r));
                        }
                    }
                    
                }
                
                public function setProducts() {
                    global $wpdb;
                    global $apiHandler;

                    $kalaList = $apiHandler->Send(get_option('tahlil_ip_port') . get_option('tahlil_api_address'), get_option('tahlil_api_pass'), get_option('tahlil_params'));

                    foreach ($kalaList as $key => $val) {

                        $post_title = $val->Onvan;
                        $post_excerpt = "";
                        $post_status = ((get_option('tahlil_api_post_status')!="")?get_option('tahlil_api_post_status'):"draft");
                        $post_type = "product";

                        $wp_error = "";

                        $product = $wpdb->get_row("SELECT * FROM " . $wpdb->posts . " WHERE post_title='$post_title' AND post_type = 'product' AND post_status <> 'trash'");

                        if ($product === null) {
                            $post = array(
                                'post_author' => 1,
                                'post_content' => '',
                                'post_status' => $post_status,
                                'post_title' => $post_title,
                                'post_parent' => '',
                                'post_type' => $post_type,
                            );

                            //Create post
                            $post_id = wp_insert_post($post, $wp_error);

                            //wp_set_object_terms( $post_id, $term_id, 'product_cat' );

                            $this->update_product($post_id, $val->KhordePrice, $val->MovjoodiGhabelForooshV1, $val->Code, $val->GCode);
                        } else {
                            $this->update_product($product->ID, $val->KhordePrice, $val->MovjoodiGhabelForooshV1, $val->Code, $val->GCode);
                        }
                    }

                    $js = json_decode(get_option('tahlil_params'));

                    if (count($kalaList) > 0) {
                        $js->PageNum = $js->PageNum + 1;
                    } else {
                        $js->PageNum = 1;
                    }

                    update_option("tahlil_params", json_encode($js));

                    return "تعداد رکوردها: " . count($kalaList);
                }

                public function db_install() {
                    global $wpdb;
                    $charset_collate = $wpdb->get_charset_collate();

                    $sql = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . TahlilApi::TableName . " (
                                id int NOT NULL AUTO_INCREMENT,
                                log_desc text DEFAULT '' NULL,
                                log_date varchar(20) NOT NULL,
                                PRIMARY KEY  (id)
                            ) $charset_collate;";

                    $wpdb->query($sql);

                    $sql = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . TahlilApi::GroupMapTable . " (
                                id int NOT NULL AUTO_INCREMENT,
                                term_id int not null,
                                term_name text DEFAULT '' NULL,
                                kalacode text DEFAULT '' NULL,
                                PRIMARY KEY  (id)
                            ) $charset_collate;";

                    $wpdb->query($sql);
                    
                    $sql = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . _APIORDERS . " (
                                id int NOT NULL AUTO_INCREMENT,
                                order_id int not null,
                                order_params text DEFAULT '' NULL,
                                order_status text DEFAULT '' NULL,
                                PRIMARY KEY  (id)
                            ) $charset_collate;";

                    $wpdb->query($sql);
                }

            }

            $tahlilApi = new TahlilApi();
        }

        function jalaliDate() {
            //jdate('H:i', $timestamp)
            date_default_timezone_set("Iran");
            $timestamp = strtotime("now");

            if (function_exists('jdate')) {
                return jdate('Y/m/d', $timestamp) . " " . jdate('H:i', $timestamp);
            } else {
                return date('Y/m/d', $timestamp) . " " . date('H:i', $timestamp);
            }
        }

        add_action('woocommerce_thankyou', 'api_factor_append', 10, 1);

        function api_factor_append($order_id) {
            if (!$order_id)
                return;

            $factorAppend = new FactorAppend();
            $factorAppend->RizFactorInfo = array();
            
            // Getting an instance of the order object
            $order = wc_get_order($order_id);

            if ($order->is_paid())
                $paid = 'yes';
            else
                $paid = 'no';

            // iterating through each order items (getting product ID and the product object) 
            // (work for simple and variable products)
            $satr = 1;
            foreach ($order->get_items() as $item_id => $item) {

                //echo $item[0];
                $rizFac = new RizFactorInfoClass();
                
                if ($item['variation_id'] > 0) {
                    $product_id = $item['variation_id']; // variable product
                } else {
                    $product_id = $item['product_id']; // simple product
                }

                // Get the product object
                $product = wc_get_product($product_id);
                
                $rizFac->Ft = 1; //فاکتور فروش
                $rizFac->SatrNum = $satr;
                $rizFac->BedBes = -1;
                $rizFac->AnbarCode = 1;
                $rizFac->KSPC = $product->get_sku(); //کد کالا
                $rizFac->Sharh = "";
                $rizFac->TV1 = $item->get_quantity();//مقدار کالا
                $rizFac->Fi = (($item->get_subtotal()==0)?1:$item->get_subtotal());//مبلغ
                $rizFac->MabK = (($item->get_subtotal()==0)?1:$item->get_subtotal()) * $item->get_quantity();//مبلغ کل
                $rizFac->DT = 0; //تخفیف سطری
                $rizFac->TMab = 0; //تخفیف کلی
                $rizFac->TV2Ex = 0;
                $rizFac->Z1 = 0;
                $rizFac->Z2 = 0;
                $rizFac->Z3 = 0;
                $rizFac->RizSID = 0;
                $rizFac->NDate = "";
                $rizFac->KalaPCode = 0;
               
                $factorAppend->RizFactorInfo[] = $rizFac;
                $satr++;
            }

            // Ouptput some data
            //echo '<p>Order ID: ' . $order_id . ' — Order Status: ' . $order->get_status() . ' — Order is paid: ' . $paid . '</p>';
            $data = $order->get_data(); // order data
            //echo "Total: ".$order->get_total()." ";
            //echo json_encode($data);
            $rndNumber = rand(1000000, 9999999);
            
            
            
            $factorAppend->PersonInfo = new PersonInfoClass();
            $factorAppend->PersonInfo->OpMode = 0; //ثبت مشتری جدید
            $factorAppend->PersonInfo->Code = "0000000";
            $factorAppend->PersonInfo->ACode = "";
            $factorAppend->PersonInfo->FCode = "";
            $factorAppend->PersonInfo->Name = $data['billing']['first_name']."_".$rndNumber;
            $factorAppend->PersonInfo->Family = $data['billing']['last_name']."_".$rndNumber;
            $factorAppend->PersonInfo->FatherName = "";
            $factorAppend->PersonInfo->MelliCode = "";
            $factorAppend->PersonInfo->Tel = $data['billing']['phone'];
            $factorAppend->PersonInfo->Mobile = $data['billing']['phone'];
            $factorAppend->PersonInfo->Address = $data['billing']['address_1'];
            
            $factorAppend->PersonInfo->BirthDay = "";
            $factorAppend->PersonInfo->PostCode = $data['billing']['postcode'];
            $factorAppend->PersonInfo->Info = "";
            
            $factorAppend->PersonInfo->PersonType = 0; //حقیقی
            $factorAppend->PersonInfo->Email = $data['billing']['email'];
            $factorAppend->PersonInfo->NameFamily2 = $data['billing']['first_name']." ".$data['billing']['last_name']."_".$rndNumber;
            $factorAppend->PersonInfo->ShomareHesab = "";
            $factorAppend->PersonInfo->Tel2 = "";
            $factorAppend->PersonInfo->Tel3 = "";
            $factorAppend->PersonInfo->Fax = "";
            $factorAppend->PersonInfo->ECode = "";
            $factorAppend->PersonInfo->ShNum = "";
            
            
            $factorAppend->FactorInfo = new FactorInfoClass();
            $factorAppend->FactorInfo->NewFt = 1;
            $factorAppend->FactorInfo->Dd = $data['date_created']->date('Y-m-d');
            $factorAppend->FactorInfo->Sharh = "";
            $factorAppend->FactorInfo->FPrice = (($order->get_total()==0)?1:$order->get_total());
            $factorAppend->FactorInfo->Naghd = (($order->get_total()==0)?1:$order->get_total());
            $factorAppend->FactorInfo->Aghsat = 0;
            $factorAppend->FactorInfo->Takhfif = 0;
            $factorAppend->FactorInfo->Nesieh = 0;
            $factorAppend->FactorInfo->Havale = 0;
            $factorAppend->FactorInfo->BedBes = 1;
            $factorAppend->FactorInfo->Ezafat = 0;
            $factorAppend->FactorInfo->Kosoorat = 0;
            $factorAppend->FactorInfo->VizitorCode = "";
            $factorAppend->FactorInfo->SaveTime = $data['date_created']->date('H:i');
            $factorAppend->FactorInfo->SumMaliat = 0;
            $factorAppend->FactorInfo->SumTakhfifSatr = 0;
            $factorAppend->FactorInfo->KCode = 1;
            $factorAppend->FactorInfo->Inf = "";
            $factorAppend->FactorInfo->PfNum = "";
            $factorAppend->FactorInfo->TasvieT = 0;
            $factorAppend->FactorInfo->PAddr = $data['billing']['address_1'];
            $factorAppend->FactorInfo->PTel = $data['billing']['phone'];
            $factorAppend->FactorInfo->SumAvarez = 0;
            $factorAppend->FactorInfo->DepC = 1;
            $factorAppend->FactorInfo->DepN = 0;
            $factorAppend->FactorInfo->Bon = 0;
            $factorAppend->FactorInfo->IsOk = true;
            $factorAppend->FactorInfo->IsCancel = false;
               
            
            $factorAppend->DaryaftiInfo = new DaryaftiInfoClass();
            
            $factorAppend->DaryaftiInfo->DayDate = $data['date_created']->date('Y-m-d');
            $factorAppend->DaryaftiInfo->BankCode = "";
            $factorAppend->DaryaftiInfo->HavaleNum = $order_id;
            $factorAppend->DaryaftiInfo->HavalePrice = (($order->get_total()==0)?1:$order->get_total());
            $factorAppend->DaryaftiInfo->DepC = 1;
            $factorAppend->DaryaftiInfo->KCode = 1;
 
//            $factorAppend->RizEzafatKosoorat = array();
//            $rizEzafat = new RizEzafatKosooratClass();
//            
//            $rizEzafat->Ft = 1;
//            $rizEzafat->BedBes = "";
//            $rizEzafat->SatrNum = "";
//            $rizEzafat->EzafKosoorCode = "";
//            $rizEzafat->Darsad = "";
//            $rizEzafat->Mablagh = "";
//            $rizEzafat->MabKol = "";
//            
//            $factorAppend->RizEzafatKosoorat[] = $rizEzafat;
            
            $myT = new TahlilApi();
            $myT->UpdateOrder($order_id, json_encode($factorAppend,JSON_UNESCAPED_UNICODE));
            
            
//            echo $data['id']."&nbsp;&nbsp;";
//            echo $data['parent_id']."&nbsp;&nbsp;";
//            echo $data['status']."&nbsp;&nbsp;";
//            echo $data['currency']."&nbsp;&nbsp;";
//            echo $data['version']."&nbsp;&nbsp;";
//            echo $data['payment_method']."&nbsp;&nbsp;";
//            echo $data['payment_method_title']."&nbsp;&nbsp;";
//            echo $data['payment_method']."&nbsp;&nbsp;";
//            echo $data['payment_method']."&nbsp;&nbsp;";
//
//// get formatted date using the method date()
//            echo $data['date_created']->date('Y-m-d H:i:s')."&nbsp;&nbsp;";
//            echo $data['date_modified']->date('Y-m-d H:i:s')."&nbsp;&nbsp;";
//
//// get the timestamp through the method getTimestamp()
//            echo $data['date_created']->getTimestamp()."&nbsp;&nbsp;";
//            echo $data['date_modified']->getTimestamp()."&nbsp;&nbsp;";
//
//// more data
//
//            echo $data['discount_total']."&nbsp;&nbsp;";
//            echo $data['discount_tax']."&nbsp;&nbsp;";
//            echo $data['shipping_total']."&nbsp;&nbsp;";
//            echo $data['shipping_tax']."&nbsp;&nbsp;";
//            echo $data['cart_tax']."&nbsp;&nbsp;";
//            echo $data['total_tax']."&nbsp;&nbsp;";
//            echo $data['customer_id']."&nbsp;&nbsp;";
//// billing - account statement
//
//            echo $data['billing']['first_name']."&nbsp;&nbsp;";
//            echo $data['billing']['last_name']."&nbsp;&nbsp;";
//            echo $data['billing']['company']."&nbsp;&nbsp;";
//            echo $data['billing']['address_1']."&nbsp;&nbsp;";
//            echo $data['billing']['address_2']."&nbsp;&nbsp;";
//            echo $data['billing']['city']."&nbsp;&nbsp;";
//            echo $data['billing']['state']."&nbsp;&nbsp;";
//            echo $data['billing']['postcode']."&nbsp;&nbsp;";
//            echo $data['billing']['country']."&nbsp;&nbsp;";
//            echo $data['billing']['email']."&nbsp;&nbsp;";
//            echo $data['billing']['phone']."&nbsp;&nbsp;";
//
//// shipping
//
//            echo $data['shipping']['first_name']."&nbsp;&nbsp;";
//            echo $data['shipping']['last_name']."&nbsp;&nbsp;";
//            echo $data['shipping']['company']."&nbsp;&nbsp;";
//            echo $data['shipping']['address_1']."&nbsp;&nbsp;";
//            echo $data['shipping']['address_2']."&nbsp;&nbsp;";
//            echo $data['shipping']['city']."&nbsp;&nbsp;";
//            echo $data['shipping']['state']."&nbsp;&nbsp;";
//            echo $data['shipping']['postcode']."&nbsp;&nbsp;";
//            echo $data['shipping']['country']."&nbsp;&nbsp;";
        }

        // add custom interval
        function cron_add_minute($schedules) {
            // Adds once every minute to the existing schedules.
            $schedules['threehours'] = array(
                'interval' => 60 * intval(get_option('tahlil_api_interval_update')), //Hours
                //'interval' =>  60 * 60 * intval(get_option('tahlil_api_interval_update')), //Hours
                'display' => __('Once in three hours')
            );
            return $schedules;
        }

        add_filter('cron_schedules', 'cron_add_minute');

        
        
        add_action('template_redirect','check_if_logged_in');
        function check_if_logged_in()
        {
            $pageid = 9; // your checkout page id
            if(is_user_logged_in() && is_page($pageid))
            {
                //$url = add_query_arg(
                //    'redirect_to',
                //    get_permalink($pagid),
                //    site_url('/wp-login.php') // your my acount url
                //);
                //wp_redirect($url);
                //exit;
            }
        }

        // create a scheduled event (if it does not exist already)
        function cronstarter_activation() {
            if (!wp_next_scheduled('mycronjob')) {
                wp_schedule_event(time(), 'threehours', 'mycronjob');
            }
        }

        // and make sure it's called whenever WordPress loads
        add_action('wp', 'cronstarter_activation');

        // here's the function we'd like to call with our cron job
        function my_repeat_function() {
            global $wpdb;
            // do here what needs to be done automatically as per your schedule
            // in this example we're sending an email
            $myT = new TahlilApi();
            $myT->SendOrders();
            $m = $myT->setProducts();
            $date = jalaliDate();
            $sql = " INSERT INTO " . $wpdb->prefix . TahlilApi::TableName . " (log_desc,log_date) values ('$m', '$date')";

            $wpdb->query($sql);
        }

        // hook that function onto our scheduled event:
        add_action('mycronjob', 'my_repeat_function');

        // unschedule event upon plugin deactivation
        function cronstarter_deactivate() {
            // find out when the last event was scheduled
            $timestamp = wp_next_scheduled('mycronjob');
            // unschedule previous event if any
            wp_unschedule_event($timestamp, 'mycronjob');
        }

        register_deactivation_hook(__FILE__, 'cronstarter_deactivate');
    });
}
