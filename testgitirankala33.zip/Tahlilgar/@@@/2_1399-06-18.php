<?php

    include_once("../classes/class.cnfg.php");
    $conf = new config();

    include_once($conf->BaseRoot.'/classes/class.main.php');
    $ths = new main();



class tahlilgar{

    var $url;
    var $apipass;
    var $post;
    var $fields;

    public function __construct(){
        global $ths;
        
        $i = $ths->Getdata($ths->query("select `id` from `tahlilgar_product` where 1 order by `update_date` desc limit 0,1;"));
        
        if($i && $i[0]->id){
            $Max = $i[0]->id;
        }else{
            $Max = 0;
        }


        #$MyEditDate_ = explode(' ',date("Y-m-d H:i:s", mktime(0, 0, 0, date('m')-6, date('d'), date('Y'))));
        #$MyEditDate = str_replace(' ', 'T', $MyEditDate_[0]);
        
        $MyEditDate = "2016-01-01";


        $this->url = "http://46.100.164.100:9002/";
        $this->apipass = "TW@638080#HK391616";
        $this->fields = "api/GetKalaList";
        $this->post = '{"WithMovjoodi":1,"Mode":"0","MinId":"'.$Max.'", "PerPage":"500", "LastGetDate":"'.$MyEditDate.'","PageNum":1}';

    }
    public function GetKalaList(){
        
        global $ths;
        
        $return = json_decode($this->post2());
    
        if($return && count($return)){
            foreach($return as $r){
                $flg = $ths->GetData($ths->query("select `id`, `price`, `price_off`, `amount1`, `amount2`, `edit_date`, `flag` from `tahlilgar_product` where `id`='".$r->ID."';"));
                
                if($flg){
                    //var_dump($r->EditDate);
                    $ths->query("update `tahlilgar_product` set `price`='".$r->KhordePrice."', `price_off`='".$r->TakhfifNaghdi."', `amount1`='".(float)$r->MovjoodiV1."', `amount2`='".(float)$r->MovjoodiGhabelForooshV1."', `edit_date`='".($r->EditDate ? str_replace('T', ' ', $r->EditDate) : '1000-01-01 00:00:00')."', `update_date`='".date('Y-m-d H:i:s')."' where `id`='".$r->ID."';");
                    
                    if($flg[0]->flag){
                       // $ths->query("");
                    }
                    
                }else{
                    $ths->query("insert into `tahlilgar_product` (`id`, `gcode`, `code`, `onvan`, `barcode`, `company`, `vahed`, `min_order`, `max_order`, `price`, `price_off`, `amount1`, `amount2`, `anbar_code`, `insert_date`, `edit_date`, `flag`, `update_date`, `createdate`) VALUES ('".$r->ID."', '".$r->GCode."', '".$r->Code."', '".$r->Onvan."', '".$r->BarCode."', '".$r->CompanyCode."', '".(int)$r->Vahed1."', '".(float)$r->MinSefaresh."', '".(float)$r->MaxSefaresh."', '".$r->KhordePrice."', '".$r->TakhfifNaghdi."', '".(float)$r->MovjoodiV1."', '".(float)$r->MovjoodiGhabelForooshV1."', '".$r->AnbarCode."', '".str_replace('T', ' ', $r->InsertDate)."', '".($r->EditDate ? str_replace('T', ' ', $r->EditDate) : '1000-01-01 00:00:00')."', '0', '".date('Y-m-d H:i:s')."', '".date('Y-m-d H:i:s')."');");
                }
            }
        }else{
            $this->post = '{"WithMovjoodi":1,"Mode":"0","MinId":"1", "PerPage":"500","LastGetDate":"2019-08-18","PageNum":1}';

            $this->GetKalaList();
        }
        
    }
    private function post2() {
        try {
            $ch = curl_init();
            $header = array();
            $header[] = "Cache-Control: no-cache";
            $header[] = 'Content-type: application/json';
            $header[] = 'apipass:' . $this->apipass;
            

            curl_setopt($ch, CURLOPT_URL, $this->url.$this->fields);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, $this->apipass);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            curl_setopt($ch, CURLOPT_AUTOREFERER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $this->post);

            $data = curl_exec($ch);
            
            curl_close($ch);
            return $data;
        }
        
        
        catch (Exception $e) {
            return "[{\"status\":-1}]";
        }
    }
}


$apiHandler = new tahlilgar();

$a = $apiHandler->GetKalaList();
  

?>