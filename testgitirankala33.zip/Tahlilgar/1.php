<?php



class tahlilgar{

    var $url;
    var $apipass;
    var $post;
    var $fields;

    public function __construct(){
        $this->url = "http://46.100.164.100:9002/";
        $this->apipass = "TW@638080#HK391616";
        $this->fields = "api/GetKalaList";
        $this->post = '{"WithMovjoodi":1,"Mode":"1","MinId":"1","PerPage":"100","LastGetDate":"2015-01-04","PageNum":1}';

    }
    public function GetKalaList(){
        return json_decode($this->post2());
    }
    private function post2() {
        try {
            $ch = curl_init();
            $header = array();
            $header[] = "Cache-Control: no-cache";
            $header[] = 'Content-type: application/json';
            $header[] = 'apipass:' . $this->apipass;
            

            curl_setopt($ch, CURLOPT_URL, $this->url.$this->fields);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, $this->apipass);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            curl_setopt($ch, CURLOPT_AUTOREFERER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $this->post);

            $data = curl_exec($ch);
            
            curl_close($ch);
            return $data;
        }
        
        
        catch (Exception $e) {
            return "[{\"status\":-1}]";
        }
    } 
}


$apiHandler = new tahlilgar();

$a = $apiHandler->GetKalaList();
            var_dump($a);

?>