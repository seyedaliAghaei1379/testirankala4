<?php
exit();
    include_once("../classes/class.cnfg.php");
    $conf = new config();

    include_once($conf->BaseRoot.'/classes/class.main.php');
    $ths = new main();

    class tahlilgar{

        var $url;
        var $apipass;
        var $post;
        var $fields;

        public function __construct(){
            global $ths;

            $this->url = "http://46.100.164.100:9002/";
            $this->apipass = "TW@638080#HK391616";

            

        }
        public function GetAddFactor0(){
            global $ths;


            $this->fields = "api/FactorAppendUpdate";
            
            
            
            
            $this->post = '{"FactorInfo":{"NewFt":1,"Pc":"0990243","Dd":"1399/06/25","Sharh":"فاکتور فروش اینترنتی","Fprice":52100000,"Naghd":0,"Aghsat":0,"Takhfif":0,"Nesieh":0,"Havale":42722000,"BedBes":1,"Ezafat":0,"Kosoorat":0,"VizitorCode":"","SaveTime":"'.date('H:i').'","SumMaliat":"0","SumTakhfifSatr":9378000,"Kcode":1,"Inf":"","PfNum":"","TasvieT":0,"Paddr":"اصفهان دانشگاه صنعتي اصفهان کوي اساتيد رديف 1 واحد 17","Ptel":"09131943522","SumAvarez":0,"DepC":1,"DepN":0,"Bon":0,"IsOk":true,"IsCancel":false},"RizFactorInfo":[{"Ft":1,"SatrNum":1,"BedBes":-1,"AnbarCode":1,"KSPC":"010010010101000100100101","Sharh":"","TV1":2,"Fi":300000,"MabK":600000,"DT":0,"Tmab":0,"TV2Ex":0,"Z1":0,"Z2":0,"Z3":0,"RizSID":0,"Ndate":"","KalaPCode":0},{"Ft":1,"SatrNum":2,"BedBes":-1,"AnbarCode":1,"KSPC":"010010010101000100100201","Sharh":"","TV1":1,"Fi":51500000,"MabK":51500000,"DT":0,"Tmab":0,"TV2Ex":0,"Z1":0,"Z2":0,"Z3":0,"RizSID":0,"Ndate":"","KalaPCode":0}],"DaryaftiInfo":{"PCode":"0990243","DayDate":"'.date('Y-m-d').'","BankCode":"","HavaleNum":"222222","HavalePrice":42722000,"DepC":1,"KCode":1}}'; 
            //,"RizEzafatKosoorat":{"Ft":1,"SatrNum":1,"BedBes":-1,"EzafKosoorCode":"","FactorMab":52100000,"Darsad":18,"Mablagh":9378000,"MabKol":0}


            $return = json_decode($this->post2());
            var_dump($return);

        }
        public function GetAddFactor(){
            global $ths;

            $this->fields = "api/FactorAppendWithPerson";
            
             $PersonInfo["OpMode"] = 0;
            $PersonInfo["Code"] = "0000000";
            $PersonInfo["ACode"] = "";
            $PersonInfo["FCode"] = 0;
            $PersonInfo["Name"] = "مجتبی";
            $PersonInfo["Family"] = "یوسفی09125542052(اینترنتی)";
            $PersonInfo["MelliCode"] = "0062864416";
            $PersonInfo["Tel"] = "02537766554";
            $PersonInfo["Mobile"] = "09125528051";
            $PersonInfo["Address"] = "قم خیابان 19 دی کوچه 25 پلاک 10";
            $PersonInfo["BirthDay"] = "";
            $PersonInfo["PostCode"] = "";
            $PersonInfo["Info"] = "";
            $PersonInfo["PersonType"] = 0;
            $PersonInfo["Email"] = "";
            $PersonInfo["NameFamily2"] = "";
            $PersonInfo["ShomareHesab"] = "";
            $PersonInfo["Tel2"] = "";
            $PersonInfo["Tel3"] = "";
            $PersonInfo["Fax"] = "";
            $PersonInfo["ECode"] = "";
            $PersonInfo["FatherName"] = "";
            $PersonInfo["ShNum"] = "";
            
            
            var_dump(json_encode((object)["PersonInfo"=>$PersonInfo]));
            echo '<hr>';
            exit;
            
            $this->post = '{"PersonInfo":{"OpMode":0,"Code":"0000000","ACode":"","FCode":0,"Name":"مجتبی","Family":"یوسفی09125542052(اینترنتی)","MelliCode":"0062864416","Tel":"02537766554","Mobile":"09125528051","Address":"قم خیابان 19 دی کوچه 25 پلاک 10","BirthDay":"","PostCode":"","Info":"","PersonType":0,"Email":"","NameFamily2":"","ShomareHesab":"","Tel2":"","Tel3":"","Fax":"","ECode":"","FatherName":"","ShNum":""},"FactorInfo":{"NewFt":1,"Pc":"","Dd":"1399/06/25","Sharh":"فاکتور فروش اینترنتی","Fprice":52100000,"Naghd":52100000,"Aghsat":0,"Takhfif":0,"Nesieh":0,"Havale":0,"BedBes":1,"Ezafat":0,"Kosoorat":0,"VizitorCode":"","SaveTime":"'.date('H:i').'","SumMaliat":"0","SumTakhfifSatr":9378000,"Kcode":1,"Inf":"","PfNum":"","TasvieT":0,"Paddr":"اصفهان دانشگاه صنعتي اصفهان کوي اساتيد رديف 1 واحد 17","Ptel":"09131943522","SumAvarez":0,"DepC":1,"DepN":0,"Bon":0,"IsOk":true,"IsCancel":false},"RizFactorInfo":[{"Ft":1,"SatrNum":1,"BedBes":-1,"AnbarCode":1,"KSPC":"010010010101000100100101","Sharh":"","TV1":2,"Fi":300000,"MabK":600000,"DT":0,"Tmab":0,"TV2Ex":0,"Z1":0,"Z2":0,"Z3":0,"RizSID":0,"Ndate":"","KalaPCode":0},{"Ft":1,"SatrNum":2,"BedBes":-1,"AnbarCode":1,"KSPC":"010010010101000100100201","Sharh":"","TV1":1,"Fi":51500000,"MabK":51500000,"DT":0,"Tmab":0,"TV2Ex":0,"Z1":0,"Z2":0,"Z3":0,"RizSID":0,"Ndate":"","KalaPCode":0}],"DaryaftiInfo":{"DayDate":"'.date('Y-m-d').'","BankCode":"","HavaleNum":"25","HavalePrice":42722000,"DepC":1,"KCode":1}}'; 
            //,"RizEzafatKosoorat":{"Ft":1,"SatrNum":1,"BedBes":-1,"EzafKosoorCode":"","FactorMab":52100000,"Darsad":18,"Mablagh":9378000,"MabKol":0}



var_dump($this->post);
exit;

            $return = json_decode($this->post2());
            var_dump($return);

        }
        public function GetKalaList(){
            global $ths;
            
            $this->fields = "api/GetKalaList";
            $this->post = '{"WithMovjoodi":1,"Mode":"0","MinId":"1","PerPage":"2","LastGetDate":"2015-01-04","PageNum":1}';

            $return = json_decode($this->post2());

            

        }
        private function post2() {
            try {
                $ch = curl_init();
                $header = array();
                $header[] = "Cache-Control: no-cache";
                $header[] = 'Content-type: application/json';
                $header[] = 'apipass:' . $this->apipass;


                curl_setopt($ch, CURLOPT_URL, $this->url.$this->fields);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
                curl_setopt($ch, CURLOPT_USERPWD, $this->apipass);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
                curl_setopt($ch, CURLOPT_AUTOREFERER, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $this->post);
                $data = curl_exec($ch);

                curl_close($ch);
                return $data;
            }
            catch (Exception $e) {
                return "[{\"status\":-1}]";
            }
        }
    }

var_dump('dddd');
exit;

    $apiHandler = new tahlilgar();

    #$a = $apiHandler->GetKalaList();
    $a = $apiHandler->GetAddFactor();
    #$a = $apiHandler->GetAddFactor0();


?>