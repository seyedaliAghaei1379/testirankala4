<?php
exit;
    include_once("../classes/class.cnfg.php");
    $conf = new config();

    include_once($conf->BaseRoot.'/classes/class.main.php');
    $ths = new main();

    class tahlilgar{

        var $url;
        var $apipass;
        var $post;
        var $fields;

        public function __construct(){
            global $ths;

            $this->url = "http://46.100.164.100:9002/";
            $this->apipass = "TW@638080#HK391616";

            

        }
        public function GetPersonList(){
            global $ths;

            $CounterFile = '/home/sarair/public_html/shop/Tahlilgar/1.txt';
            $Counter = file_get_contents($CounterFile);
            $Counter ++;

            $MyEditDate_ = explode(' ',date("Y-m-d H:i:s", mktime(0, 0, 0, date('m'), date('d'), date('Y')-4)));


            $this->fields = "api/GetPersonList";
            $this->post = '{"PageNum":"'.$Counter.'","PerPage":"500"}'; 
            

            $return = json_decode($this->post2());

           if($return && count($return)){
                foreach($return as $r){
                    
                    $flg = $ths->GetData($ths->query("select `id` from `tahlilgar_user` where `code`='".$r->Code."';"));
                
                if($flg){
                    
                    #$ths->query("update `tahlilgar_user` set `acode`='".$r->ACode."', `fcode`='".$r->FCode."', `name`='".$r->Name."', `family`='".$r->Family."', `father_name`='".$r->FatherName."', `mellicode`='".$r->MelliCode."', `mobile`='".$r->Mobile."', `tel`='".$r->Tel."', `address`='".$r->Address."', `ostan_id`='".$r->OstanCode."', `ostan`='".$r->OstanOnvan."', `city_id`='".$r->CityID."', `city`='".$r->CityOnvan."', `edit_date`='".$r->EditDate."', `postcode`='".$r->PostCode."' where `code`='".$r->Code."'; ");
                    
                }else{
                    $ths->query("insert into `tahlilgar_user` ( `code`, `acode`, `fcode`, `name`, `family`, `father_name`, `mellicode`, `mobile`, `tel`, `address`, `ostan_id`, `ostan`, `city_id`, `city`,  `postcode`, `insert_date`, `edit_date`) VALUES ('".$r->Code."', '".$r->ACode."', '".$r->FCode."', '".$r->Name."', '".$r->Family."', '".$r->FatherName."', '".$r->MelliCode."', '".$r->Mobile."', '".$r->Tel."', '".$r->Address."', '".$r->OstanCode."', '".$r->OstanOnvan."', '".$r->CityID."', '".$r->CityOnvan."', '".$r->PostCode."', '".$r->InsertDate."', '".$r->EditDate."')");
                }
                    
                }
                
                file_put_contents($CounterFile, $Counter);
            }

        }
        public function GetKalaList(){
            global $ths;
            
            $this->fields = "api/GetKalaList";
            $this->post = '{"WithMovjoodi":1,"Mode":"0","MinId":"1","PerPage":"2","LastGetDate":"2015-01-04","PageNum":1}';

            $return = json_decode($this->post2());

            

        }
        private function post2() {
            try {
                $ch = curl_init();
                $header = array();
                $header[] = "Cache-Control: no-cache";
                $header[] = 'Content-type: application/json';
                $header[] = 'apipass:' . $this->apipass;


                curl_setopt($ch, CURLOPT_URL, $this->url.$this->fields);
                curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
                curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
                curl_setopt($ch, CURLOPT_USERPWD, $this->apipass);
                curl_setopt($ch, CURLOPT_POST, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
                curl_setopt($ch, CURLOPT_AUTOREFERER, true);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $this->post);
                $data = curl_exec($ch);

                curl_close($ch);
                return $data;
            }
            catch (Exception $e) {
                return "[{\"status\":-1}]";
            }
        }
    }


    $apiHandler = new tahlilgar();

    #$a = $apiHandler->GetKalaList();
    $a = $apiHandler->GetPersonList();


?>