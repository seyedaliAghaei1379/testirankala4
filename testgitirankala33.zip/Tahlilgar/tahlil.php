<?php

include_once("../classes/class.cnfg.php");
$conf = new config();

include_once($conf->BaseRoot.'/classes/class.main.php');
$ths = new main();


include_once($conf->BaseRoot.'classes/class.libs_parent.php');

include_once($conf->BaseRoot.'classes/libs/class.product.php');
$ProductClass = new product();

include_once($conf->BaseRoot.'classes/libs/class.product_rel.php');
$ProdRelClass = new product_rel();

include_once($conf->BaseRoot.'classes/libs/class.tahlilgar_product.php');
$TahlilClass = new tahlilgar_product();

class tahlilgar{

    var $url;
    var $apipass;
    var $post;
    var $fields;
    var $MyCount;
    var $MyCountArr;

    public function __construct(){
        global $ths;
        $this->MyCount = 100; 
        $MyCodeList = [];
        $this->MyCountArr = [];

        $MyList = $ths->Getdata($ths->query("select `code` from `tahlilgar_product2` where `flag`=1 order by `update_date` asc, `id0` asc limit 0,".$this->MyCount.";")); //

        if($MyList && is_array($MyList)){
            foreach($MyList as $l){
                $MyCodeList[] = $l->code;
                //$this->MyCountArr[$l->code] = $l->count;
            }
        }
        
       

        //$MyCodeList = [14300100702];

        $MyEditDate = date("Y-m-d H:i:s", mktime(date('H'), date('i'), date('s'), date('m'), date('d'), date('Y')-1));
        $MyEditDate = str_replace(' ', 'T', $MyEditDate);

        $MyEditDate .= ".552556+03:30";

        $this->url = "http://46.100.164.100:9002/";
        $this->apipass = "TW@638080#HK391616";
        $this->fields = "api/CommonApi/GetKalaList";


        $this->post = '{"WithMovjoodi":true, "KalaCode":"", "MinId":0,  "KalaCodeList":"'.implode(',', $MyCodeList).'", "Mode":2, "AnbarCodeList":"44,45,7,1,48", "L1Len":2, "L2Len":2, "L3Len":2, "L4Len":3, "L5Len":2, "L6Len":1, "L7Len":2, "L8Len":0, "PageNum":1, "PerPage":'.$this->MyCount.', "LastGetDate":"'.$MyEditDate.'"}';
        
    }
    public function GetKalaList(){

        global $ths, $ProdRelClass, $ProductClass;

        $return = json_decode($this->post2());

var_dump($return);
exit;
#echo '<hr>';

        $MyIDs = [];
        $this->MyCountArr = [];
        $Threshold = 3;

        if($return && count($return)){
            
            $LastId = $return[count($return) - 1]->Code; 
            
            foreach($return as $r){
                if($r->Code != $LastId && !in_array($r->Code, $MyIDs)){
                    $MyIDs[] = $r->Code;
                }
            }
            
            foreach($return as $r){
                if(!in_array($r->Code, $MyIDs)){ break;}
    
                if(isset($this->MyCountArr[$r->Code])){
                    $MyCntArr = $ths->MyDecode($this->MyCountArr[$r->Code]);
                }
    
                #if(in_array($r->AnbarCode, [44, 45, 7, 1, 48])){
                    $MyCntArr[(int)$r->AnbarCode] = (float)$r->MovjoodiGhabelForooshV1;//MovjoodiV1;
                    $this->MyCountArr[$r->Code] = $ths->MyEncode($MyCntArr);
                #}
            }
        }

#var_dump($this->MyCountArr[$r->Code]);


        $DoneIDs = [];

        if($return && count($return)){
            foreach($return as $r){

                if(!in_array($r->Code, $MyIDs)){ break;}
                if(in_array($r->Code, $DoneIDs)){ continue; }

                $DoneIDs[] = $r->Code;

                $Cnt = 0;
                $MyCntArr = $ths->MyDecode($this->MyCountArr[$r->Code]);
                foreach($MyCntArr as $cntti=>$cntt){
                    if(in_array($cntti, [44, 45, 7, 1, 48])){
                        //$Cnt += $cntt;
                        $Cnt = $cntt;
                    }
                }


                echo $qry = "update `tahlilgar_product2` set `price`='".$r->KhordePrice."', `amount`='".(isset($this->MyCountArr[$r->Code]) ? $this->MyCountArr[$r->Code] : '{}')."' , `amount2`='".$Cnt."', `edit_date`='".($r->EditDate ? str_replace('T', ' ', $r->EditDate) : '1000-01-01 00:00:00')."', `update_date`='".date('Y-m-d H:i:s')."', `company`='".$r->CompanyCode."' where `code`='".$r->Code."';";
                $ths->query($qry);





                $Flagg = $ProdRelClass->get_all_price([['code',$r->Code], ['confirm', 1]]);

                if($Flagg){
                    $ProdID = $Flagg[0]->product_id;


                    $ProdRelClass->update_price($Flagg[0]->id, ['code2'=>$r->CompanyCode]);


                    $Min = $Max = $r->KhordePrice;
                    foreach($Flagg as $alp){
                        if($alp->price_off < $Min){ $Min = $alp->price_off;}
                        if($alp->price_off > $Max){ $Max = $alp->price_off;}
                    }

                    $IsChange = false;

                    $count_ = $ths->MyDecode($Flagg[0]->count_info);
                    
                    if(($Cnt - $Threshold) != $count_['avail_count']){
                        $IsChange = true;
                    }
                    
                    $count_['avail_count'] = $Cnt - $Threshold;
                    
                    if(!isset($count_['min_count_for_alarm']) || $count_['min_count_for_alarm'] == 0){
                        $count_['min_count_for_alarm'] = 3;
                    }
                    if(!isset($count_['min_in_order']) || $count_['min_in_order'] == 0){
                        $count_['min_in_order'] = 1;
                    }
                    if(!isset($count_['max_in_order']) || $count_['max_in_order'] == 0){
                        $count_['max_in_order'] = 2;
                    }
                    if(!isset($count_['show_avail_count']) || $count_['show_avail_count'] == 0){
                        $count_['show_avail_count'] = 10;
                    }
                    $count_2 = $ths->MyEncode($count_);

                    if($Flagg[0]->price != $r->KhordePrice){
                        $IsChange = true;
                    }
                    
                    
                    if(/*false &&*/ $IsChange){
                        $Cnfg = $ths->getSetting();

                        $AddArr2 = ['product_id'=>$ProdID,
                                    'code'=>$r->Code,
                                    'code2'=>$r->CompanyCode,
                                    'prop'=>$Flagg[0]->prop,
                                    'price'=>$r->KhordePrice,
                                    'price_off'=>($r->KhordePrice - round($r->KhordePrice * $Cnfg['PriceOffPercent'] / 100)),
                                    'confirm'=>1,
                                    'price_info'=>'{min:'.$Min.';max:'.$Max.';}',
                                    'count_info'=>$count_2,
                                    'creator_id'=>1,
                                    'createdate'=> date('Y-m-d H:i:s'),
                                    'update_count_date'=> date('Y-m-d H:i:s')];

                        $ProdRelClass->add_price($AddArr2);

                        $ProdRelClass->update_price($Flagg[0]->id, ['confirm'=>0]);
                        
                        
                        
                        //update Avail
                        $fl = $ProdRelClass->get_all_price([['product_id', $ProdID], ['confirm', 1]]);
                        if($fl){
                            $NoAvail = 0;
                            foreach($fl as $fll){
                                $cifl = $ths->MyDecode($fll->count_info);
                                if($cifl && $cifl['avail_count'] <= 0){
                                    $NoAvail++;
                                }
                            }
                            if($NoAvail == count($fl)){
                                $ProductClass->update($ProdID, ['confirm_count'=>0]);
                            }elseif($NoAvail < count($fl)){
                                $ProductClass->update($ProdID, ['confirm_count'=>1]);
                            }
                        }
                    }
                    
                }
            }
        }

    }
    private function post2() {
        try {
            $ch = curl_init();
            $header = array();
            $header[] = "Cache-Control: no-cache";
            $header[] = 'Content-type: application/json';
            $header[] = 'apipass:' . $this->apipass;


            curl_setopt($ch, CURLOPT_URL, $this->url.$this->fields);
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
            curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
            curl_setopt($ch, CURLOPT_USERPWD, $this->apipass);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
            curl_setopt($ch, CURLOPT_AUTOREFERER, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $this->post);

            $data = curl_exec($ch);

            curl_close($ch);
            return $data;
        }


        catch (Exception $e) {
            return "[{\"status\":-1}]";
        }
    }
}


$apiHandler = new tahlilgar();

$a = $apiHandler->GetKalaList();


?>