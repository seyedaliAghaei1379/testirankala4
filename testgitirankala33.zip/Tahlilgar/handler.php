<?php

/**
 * Plugin Name: TahlilApi
 * Plugin URI: http://sarayeiranishop.com/
 * Description: Tahlil Web Service.
 * Version: 1.0.0
 * Author: hssin
 * Author URI: https://sarayeiranishop.com/
 * License: GPL2
 */
defined('ABSPATH') or die('Plugin file cannot be accessed directly.');

include 'inc/Constants.inc.php';
include 'TahlilAdmin.php';
include 'inc/Classes.inc.php';

/**
 * Check if WooCommerce is active
 * */
if (in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))) {
    // Put your plugin code here

    add_action('woocommerce_loaded', function () {

        //Check if TahlilApi Class is exists 
        if (!class_exists('TahlilApi')) {

            class TahlilApi {

                const TableName = _TABLENAME;
                const GroupMapTable = _APIGROUPMAP;

                public function __construct() {
                    global $apiHandler;
                    require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );

                    //echo "ssss";
                    //echo $apiHandler->GetKalaList1(get_option('tahlil_ip_port') . get_option('tahlil_api_address'), get_option('tahlil_api_pass'), get_option('tahlil_params') );
                    //Create Log Table
                    //echo rand(1000000, 9999999)."<br/><br/><br/>";
                    //echo "sssfffffffffffffffffffffffffffffffffffffffffffffffffffffff";
                    
                    //$this->update_persons();
                    $this->db_install();
                }

                public function get_person_code($mobileNumber)
                {
                    $ps = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . _APIPERSONS . " WHERE Mobile='$mobileNumber'");
                    
                    if($ps!==null){
                        return $ps->Code;
                    }else
                        return null;
                }
                
                public function update_persons(){
                    global $apiHandler;
                    global $wpdb;
                    
                    $persons = $apiHandler->Send(get_option('tahlil_ip_port').get_option('tahlil_api_person_address'),get_option('tahlil_api_pass'),get_option('tahlil_persons_params') );
                    
                    $js = json_decode(get_option('tahlil_persons_params'));

                    if (count($persons) > 0) {
                        $js->PageNum = $js->PageNum + 1;
                    } else {
                        $js->PageNum = 1;
                    }

                    update_option("tahlil_persons_params", json_encode($js));
                    
                    foreach ($persons as $person) {
                        $Code = $person->Code;
                        $ACode = $person->ACode; 
                        $FCode = $person->FCode;
                        $Name = $person->Name;
                        $Family = $person->Family;
                        $FatherName = $person->FatherName;
                        $ShNum = $person->ShNum;
                        $MelliCode = $person->MelliCode; 
                        $Tel = $person->Tel;
                        $Tel2 = $person->Tel2;
                        $Tel3 = $person->Tel3;
                        $Mobile = $person->Mobile; 
                        $Fax = $person->Fax;
                        $Address = $person->Address; 
                        $BirthDay = $person->BirthDay;
                        $ECode = $person->ECode;
                        $PostCode = $person->PostCode; 
                        $Info = $person->Info;
                        $NameFamily2 = $person->NameFamily2; 
                        $ShomareHesab = $person->ShomareHesab;
                        $NameFamily = $person->NameFamily;
                        $Email = $person->Email;
                        $GroohAsli = $person->GroohAsli;
                        $GroohFarei = $person->GroohFarei;
                        $FoundMethodCode = $person->FoundMethodCode; 
                        $FoundMethodOnvan = $person->FoundMethodOnvan;
                        $JobCode = $person->JobCode;
                        $JobOnvan = $person->JobOnvan;
                        $OstanCode = $person->OstanCode;
                        $OstanOnvan = $person->OstanOnvan;
                        $CityID = (($person->CityID==null || $person->CityID =="")?0:$person->CityID);
                        $CityOnvan = $person->CityOnvan; 
                        $InsertDate = $person->InsertDate;
                        $EditDate = $person->EditDate;
                        $RowNumber = $person->RowNumber;
                       
                        $op = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . _APIPERSONS . " WHERE Code='$Code'");
                        
                        if ($op === null) {
                            $sql =  " INSERT INTO " . $wpdb->prefix . _APIPERSONS . 
                                    " (Code, ACode, FCode, Name, Family, FatherName, ShNum,
                                        MelliCode, Tel, Tel2, Tel3, Mobile, Fax, Address, BirthDay, ECode,
                                        PostCode, Info, NameFamily2, ShomareHesab, NameFamily, Email,GroohAsli,
                                        GroohFarei, FoundMethodCode, FoundMethodOnvan, JobCode, JobOnvan, OstanCode,
                                        OstanOnvan, CityID, CityOnvan, InsertDate, EditDate, RowNumber) ".
                                    " values ('$Code', '$ACode', '$FCode', '$Name', '$Family', '$FatherName', '$ShNum',
                                        '$MelliCode', '$Tel', '$Tel2', '$Tel3', '$Mobile', '$Fax', '$Address', '$BirthDay', '$ECode',
                                        '$PostCode', '$Info', '$NameFamily2', '$ShomareHesab', '$NameFamily', '$Email', '$GroohAsli',
                                        '$GroohFarei', '$FoundMethodCode', '$FoundMethodOnvan', '$JobCode', '$JobOnvan', '$OstanCode',
                                        '$OstanOnvan', $CityID, '$CityOnvan', '$InsertDate', '$EditDate', $RowNumber)";

                            $wpdb->query($sql);
                        }else{
                            $sql =  " UPDATE " . $wpdb->prefix . _APIPERSONS . 
                                    " SET Code = '$Code', ACode = '$ACode', FCode = '$FCode', Name = '$Name', Family = '$Family', FatherName = '$FatherName', ShNum = '$ShNum',
                                        MelliCode = '$MelliCode', Tel = '$Tel', Tel2 = '$Tel2', Tel3 = '$Tel3', Mobile = '$Mobile', Fax = '$Fax', Address = '$Address', BirthDay = '$BirthDay', ECode = '$ECode',
                                        PostCode = '$PostCode', Info = '$Info', NameFamily2 = '$NameFamily2', ShomareHesab = '$ShomareHesab', NameFamily = '$NameFamily', Email = '$Email', GroohAsli = '$GroohAsli',
                                        GroohFarei = '$GroohFarei', FoundMethodCode = '$FoundMethodCode', FoundMethodOnvan = '$FoundMethodOnvan', JobCode = '$JobCode', JobOnvan = '$JobOnvan', OstanCode = '$OstanCode',
                                        OstanOnvan = '$OstanOnvan', CityID = $CityID, CityOnvan = '$CityOnvan', InsertDate = '$InsertDate', EditDate = '$EditDate', RowNumber = $RowNumber".
                                    " WHERE Code='$Code'";

                            $wpdb->query($sql);
                        }
                    
                    //Code, ACode, FCode, Name, Family, FatherName, ShNum,
                    //MelliCode, Tel, Tel2, Tel3, Mobile, Fax, Address, BirthDay, ECode,
                    //PostCode, Info, NameFamily2, ShomareHesab, NameFamily, Email,GroohAsli,
                    //GroohFarei, FoundMethodCode, FoundMethodOnvan, JobCode, JobOnvan, OstanCode,
                    //OstanOnvan, CityID, CityOnvan, InsertDate, EditDate, RowNumber
                    
                    }
                }
                
                public function update_product($product_id, $_price, $_quantity, $_sku, $_gcode, $_anbar_code) {
                    global $wpdb;
                    $ecd_product = new WC_Product($product_id);
                    /**
                     * Check if product exists
                     */
                    if ($ecd_product->exists()) {
                        /**
                         * Get current (discounted) sales price for calculations etc
                         */
                        $sale_price = $ecd_product->sale_price;
                        /**
                         * Get regular price for calculations etc
                         */
                        $regular_price = $ecd_product->regular_price;
                        /**
                         * Get price (the actually price that people will pay)
                         * NOTE: If you set sales price different, this should be same as sales price
                         */
                        $price = $ecd_product->price;
                        /**
                         * Update sales price
                         */
                        //$rp = update_post_meta($ecd_product->id, '_regular_price', '1000');
                        $sp = update_post_meta($ecd_product->id, '_sale_price', $_price);
                        $p = update_post_meta($ecd_product->id, '_price', $_price);
                        $ms = update_post_meta($ecd_product->id, '_manage_stock', 'yes');
                        $q = update_post_meta($ecd_product->id, '_stock', $_quantity);
                        $sku = update_post_meta($ecd_product->id, '_sku', $_sku);
                        $anbar_code = update_post_meta($ecd_product->id, '_anbar_code', $_anbar_code);


                        $term = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . _APIGROUPMAP . " WHERE kalacode LIKE'%" . $_gcode . "%'");

                        if ($term !== null) {
                            foreach ($term as $k => $v) {
                                $term_rel = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . "term_relationships WHERE object_id=" . $ecd_product->id . " AND term_taxonomy_id=" . $v->term_id);

                                if ($term_rel === null) {
                                    $sql = " INSERT INTO " . $wpdb->prefix . "term_relationships (object_id,term_taxonomy_id,term_order) values (" . $ecd_product->id . "," . $v->term_id . ", 0)";

                                    $wpdb->query($sql);
                                }
                            }
                        }
                    }
                }

                public function UpdateOrder($order_id,$order_params){
                    global $wpdb;
                    
                    //echo $order_params;
                    
                    $term = $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . _APIORDERS . " WHERE order_id=" . $order_id);

                    if ($term === null) {
                        $sql = " INSERT INTO " . $wpdb->prefix . _APIORDERS . " (order_id,order_params,order_status) values (" . $order_id . ",'" . $order_params . "', '')";

                        $wpdb->query($sql);
                    } else {
                        $sql = " UPDATE " . $wpdb->prefix . _APIORDERS . " SET order_params = '" . $order_params . "' WHERE order_id=" . $order_id;

                        $wpdb->query($sql);
                    }
                    
                    $this->SendOrders();
                }
                
                public function UpdateOrderStatus($order_id,$status){
                    global $wpdb;
                    
                    $sql = " UPDATE " . $wpdb->prefix . _APIORDERS . " SET order_status = '" . $status . "' WHERE order_id=" . $order_id;
                    $wpdb->query($sql);
                }
                
                public function getOrder($order_id){
                    global $wpdb;
                    return $wpdb->get_row("SELECT * FROM " . $wpdb->prefix . _APIORDERS . " WHERE order_id=" . $order_id);
                }
                
                public function SendOrders() {
                    global $wpdb;
                    global $apiHandler;
                    
                    $res = $wpdb->get_results("SELECT * FROM " . $wpdb->prefix . _APIORDERS . " WHERE (1=1)");
                    
                    foreach ($res as $row)
                    {
                        $status = json_decode($row->order_status);
                        
                        if(trim($row->order_status)==""){
                            $r = $apiHandler->Send(get_option('tahlil_ip_port') . "api/FactorAppendWithPerson", get_option('tahlil_api_pass'), $row->order_params);
                            $this->UpdateOrderStatus($row->order_id, json_encode($r));
                        }
                    }
                    
                }
                
                public function setProducts() {
                    global $wpdb;
                    global $apiHandler;

                    $kalaList = $apiHandler->Send(get_option('tahlil_ip_port') . get_option('tahlil_api_address'), get_option('tahlil_api_pass'), get_option('tahlil_params'));

                    foreach ($kalaList as $key => $val) {

                        $post_title = $val->Onvan;
                        $post_excerpt = "";
                        $post_status = ((get_option('tahlil_api_post_status')!="")?get_option('tahlil_api_post_status'):"draft");
                        $post_type = "product";

                        $wp_error = "";

                        $product = $wpdb->get_row("SELECT * FROM " . $wpdb->posts . " WHERE post_title='$post_title' AND post_type = 'product' AND post_status <> 'trash'");

                        if ($product === null) {
                            $post = array(
                                'post_author' => 1,
                                'post_content' => '',
                                'post_status' => $post_status,
                                'post_title' => $post_title,
                                'post_parent' => '',
                                'post_type' => $post_type,
                            );

                            //Create post
                            $post_id = wp_insert_post($post, $wp_error);

                            //wp_set_object_terms( $post_id, $term_id, 'product_cat' );

                            $this->update_product($post_id, $val->KhordePrice, $val->MovjoodiGhabelForooshV1, $val->Code, $val->GCode, $val->AnbarCode);
                        } else {
                            $this->update_product($product->ID, $val->KhordePrice, $val->MovjoodiGhabelForooshV1, $val->Code, $val->GCode, $val->AnbarCode);
                        }
                    }

                    $js = json_decode(get_option('tahlil_params'));

                    if (count($kalaList) > 0) {
                        $js->PageNum = $js->PageNum + 1;
                    } else {
                        $js->PageNum = 1;
                    }

                    update_option("tahlil_params", json_encode($js));

                    return "تعداد رکوردها: " . count($kalaList);
                }

                public function db_install() {
                    global $wpdb;
                    $charset_collate = $wpdb->get_charset_collate();

                    $sql = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . TahlilApi::TableName . " (
                                id int NOT NULL AUTO_INCREMENT,
                                log_desc text DEFAULT '' NULL,
                                log_date varchar(20) NOT NULL,
                                PRIMARY KEY  (id)
                            ) $charset_collate;";

                    $wpdb->query($sql);

                    $sql = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . TahlilApi::GroupMapTable . " (
                                id int NOT NULL AUTO_INCREMENT,
                                term_id int not null,
                                term_name text DEFAULT '' NULL,
                                kalacode text DEFAULT '' NULL,
                                PRIMARY KEY  (id)
                            ) $charset_collate;";

                    $wpdb->query($sql);
                    
                    $sql = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . _APIORDERS . " (
                                id int NOT NULL AUTO_INCREMENT,
                                order_id int not null,
                                order_params text DEFAULT '' NULL,
                                order_status text DEFAULT '' NULL,
                                PRIMARY KEY  (id)
                            ) $charset_collate;";

                    $wpdb->query($sql);
                    
                    
                    $sql = "CREATE TABLE IF NOT EXISTS " . $wpdb->prefix . _APIPERSONS . " (
                                id int NOT NULL AUTO_INCREMENT,
                                Code tinytext,
                                ACode tinytext,
                                FCode tinytext,
                                Name text,
                                Family text,
                                FatherName text,
                                ShNum tinytext,
                                MelliCode tinytext,
                                Tel tinytext,
                                Tel2 tinytext,
                                Tel3 tinytext,
                                Mobile tinytext,
                                Fax tinytext,
                                Address text,
                                BirthDay tinytext,
                                ECode tinytext,
                                PostCode tinytext,
                                Info text,
                                NameFamily2 text,
                                ShomareHesab tinytext,
                                NameFamily text,
                                Email tinytext,
                                GroohAsli text,
                                GroohFarei text,
                                FoundMethodCode tinytext,
                                FoundMethodOnvan tinytext,
                                JobCode tinytext,
                                JobOnvan text, 
                                OstanCode int,
                                OstanOnvan text,
                                CityID int,
                                CityOnvan text,
                                InsertDate tinytext,
                                EditDate tinytext,
                                RowNumber int,
                                PRIMARY KEY  (id)
                            ) $charset_collate;";

                    $wpdb->query($sql);
                    
                }

            }

            $tahlilApi = new TahlilApi();
        }

        
        
        function getStateLabel($state)
        {
            switch($state)
            {
                case "ABZ":
                    return "البرز";
                    break;
                case "ADL":
                    return "اردبیل";
                    break;
                case "EAZ":
                    return "آذربایجان شرقی";
                    break;
                case "WAZ":
                    return "آذربایجان غربی";
                    break;
                case "BHR":
                    return "بوشهر";
                    break;
                case "CHB":
                    return "چهارمحال و بختیاری";
                    break;
                case "FRS":
                    return "فارس";
                    break;
                case "GIL":
                    return "گیلان";
                    break;
                case "GLS":
                    return "گلستان";
                    break;
                case "HDN":
                    return "همدان";
                    break;
                case "HRZ":
                    return "هرمزگان";
                    break;
                case "ILM":
                    return "ایلام";
                    break;
                case "ESF":
                    return "اصفهان";
                    break;
                case "KRN":
                    return "کرمان";
                    break;
                case "KRH":
                    return "کرمانشاه";
                    break;
                case "NKH":
                    return "خراسان شمالی";
                    break;
                case "RKH":
                    return "خراسان رضوی";
                    break;
                case "SKH":
                    return "خراسان جنوبی";
                    break;
                case "KHZ":
                    return "خوزستان";
                    break;
                case "KBD":
                    return "کهگیلویه و بویراحمد";
                    break;
                case "KRD":
                    return "کردستان";
                    break;
                case "LRS":
                    return "لرستان";
                    break;
                case "MKZ":
                    return "مرکزی";
                    break;
                case "MZN":
                    return "مازندران";
                    break;
                case "GZN":
                    return "قزوین";
                    break;
                case "QHM":
                    return "قم";
                    break;
                case "SMN":
                    return "سمنان";
                    break;
                case "SBN":
                    return "سیستان و بلوچستان";
                    break;
                case "THR":
                    return "تهران";
                    break;
                case "YZD":
                    return "یزد";
                    break;
                case "ZJN":
                    return "زنجان";
                    break;
                default:
                    return $state;
                    break;
            }
            
        }
        function jalaliDate() {
            //jdate('H:i', $timestamp)
            date_default_timezone_set("Iran");
            $timestamp = strtotime("now");

            if (function_exists('jdate')) {
                return jdate('Y/m/d', $timestamp) . " " . jdate('H:i', $timestamp);
            } else {
                return date('Y/m/d', $timestamp) . " " . date('H:i', $timestamp);
            }
        }

        add_action('woocommerce_thankyou', 'api_factor_append', 10, 1);

        function api_factor_append($order_id) {
            if (!$order_id)
                return;

            $factorAppend = new FactorAppendWithPerson();
            $factorAppend->RizFactorInfo = array();
            
            // Getting an instance of the order object
            $order = wc_get_order($order_id);

            if ($order->is_paid())
                $paid = 'yes';
            else
                $paid = 'no';

            // iterating through each order items (getting product ID and the product object) 
            // (work for simple and variable products)
            $satr = 1;
            foreach ($order->get_items() as $item_id => $item) {

                //echo $item[0];
                $rizFac = new RizFactorInfoClass();
                
                if ($item['variation_id'] > 0) {
                    $product_id = $item['variation_id']; // variable product
                } else {
                    $product_id = $item['product_id']; // simple product
                }

                // Get the product object
                $product = wc_get_product($product_id);
                
                $anbar_code = $product->get_meta('_anbar_code');
                
                $rizFac->Ft = 1; //فاکتور فروش
                $rizFac->SatrNum = $satr;
                $rizFac->BedBes = -1;
                $rizFac->AnbarCode = (($anbar_code!=null && $anbar_code!="")?$anbar_code:1);
                $rizFac->KSPC = $product->get_sku(); //کد کالا
                $rizFac->Sharh = $product->get_name(); //نام کالا
                $rizFac->TV1 = $item->get_quantity();//مقدار کالا
                $rizFac->Fi = (($item->get_subtotal()==0)?1:$item->get_subtotal());//مبلغ
                $rizFac->MabK = (($item->get_subtotal()==0)?1:$item->get_subtotal()) * $item->get_quantity();//مبلغ کل
                $rizFac->DT = 0; //تخفیف سطری
                $rizFac->TMab = 0; //تخفیف کلی
                $rizFac->TV2Ex = 0;
                $rizFac->Z1 = 0;
                $rizFac->Z2 = 0;
                $rizFac->Z3 = 0;
                $rizFac->RizSID = 0;
                $rizFac->NDate = "";
                $rizFac->KalaPCode = 0;
               
                $factorAppend->RizFactorInfo[] = $rizFac;
                $satr++;
            }

            // Ouptput some data
            //echo '<p>Order ID: ' . $order_id . ' — Order Status: ' . $order->get_status() . ' — Order is paid: ' . $paid . '</p>';
            $data = $order->get_data(); // order data
            //echo "Total: ".$order->get_total()." ";
            //echo json_encode($data);
            $rndNumber = rand(1000000, 9999999);
            
            
            $factorAppend->PersonInfo = new PersonInfoClass();
            $factorAppend->PersonInfo->OpMode = 0; //ثبت مشتری جدید
            $factorAppend->PersonInfo->Code = "0000000";
            $factorAppend->PersonInfo->ACode = "07";
            $factorAppend->PersonInfo->FCode = "07006";
            $factorAppend->PersonInfo->Name = $data['billing']['first_name'];
            $factorAppend->PersonInfo->Family = $data['billing']['last_name']." _ ".$data['billing']['phone'] . "(اینترنتی)";
            $factorAppend->PersonInfo->FatherName = "";
            $factorAppend->PersonInfo->MelliCode = "";
            $factorAppend->PersonInfo->Tel = $data['billing']['phone'];
            $factorAppend->PersonInfo->Mobile = $data['billing']['phone'];
            $factorAppend->PersonInfo->Address = getStateLabel($data['billing']['state'])." / ".$data['billing']['city'] . " / ".$data['billing']['postcode']." / ".$data['billing']['address_1'];
            
            $factorAppend->PersonInfo->BirthDay = "";
            $factorAppend->PersonInfo->PostCode = $data['billing']['postcode'];
            $factorAppend->PersonInfo->Info = "";
            
            $factorAppend->PersonInfo->PersonType = 0; //حقیقی
            $factorAppend->PersonInfo->Email = $data['billing']['email'];
            $factorAppend->PersonInfo->NameFamily2 = $data['billing']['first_name']." ".$data['billing']['last_name']."_".$data['billing']['phone'];
            $factorAppend->PersonInfo->ShomareHesab = "";
            $factorAppend->PersonInfo->Tel2 = "";
            $factorAppend->PersonInfo->Tel3 = "";
            $factorAppend->PersonInfo->Fax = "";
            $factorAppend->PersonInfo->ECode = "";
            $factorAppend->PersonInfo->ShNum = "";
            
            
            $factorAppend->FactorInfo = new FactorInfoWithPersonClass();
            $factorAppend->FactorInfo->NewFt = 1;
            $factorAppend->FactorInfo->Dd = $data['date_created']->date('Y-m-d');
            $factorAppend->FactorInfo->Sharh = "خرید اینترنتی";
            $factorAppend->FactorInfo->FPrice = (($order->get_total()==0)?1:$order->get_total());
            $factorAppend->FactorInfo->Naghd = 0;
            $factorAppend->FactorInfo->Aghsat = 0;
            $factorAppend->FactorInfo->Takhfif = 0;
            $factorAppend->FactorInfo->Nesieh = 0;
            $factorAppend->FactorInfo->Havale = (($order->get_total()==0)?1:$order->get_total());
            $factorAppend->FactorInfo->BedBes = 1;
            $factorAppend->FactorInfo->Ezafat = 0;
            $factorAppend->FactorInfo->Kosoorat = 0;
            $factorAppend->FactorInfo->VizitorCode = "";
            $factorAppend->FactorInfo->SaveTime = $data['date_created']->date('H:i');
            $factorAppend->FactorInfo->SumMaliat = 0;
            $factorAppend->FactorInfo->SumTakhfifSatr = 0;
            $factorAppend->FactorInfo->KCode = 1;
            $factorAppend->FactorInfo->Inf = "- فروشگاه سرای ایرانی";
            $factorAppend->FactorInfo->PfNum = "";
            $factorAppend->FactorInfo->TasvieT = 0;
            $factorAppend->FactorInfo->PAddr = getStateLabel($data['billing']['state'])." / ".$data['billing']['city']." / ".$data['billing']['phone']." / ".$data['billing']['postcode']." / ".$data['billing']['address_1'];
            $factorAppend->FactorInfo->PTel = $data['billing']['phone'];
            $factorAppend->FactorInfo->SumAvarez = 0;
            $factorAppend->FactorInfo->DepC = 1;
            $factorAppend->FactorInfo->DepN = 0;
            $factorAppend->FactorInfo->Bon = 0;
            $factorAppend->FactorInfo->IsOk = true;
            $factorAppend->FactorInfo->IsCancel = false;
               
            
            $factorAppend->DaryaftiInfo = new DaryaftiInfoClass();
            
            $factorAppend->DaryaftiInfo->DayDate = $data['date_created']->date('Y-m-d');
            $factorAppend->DaryaftiInfo->BankCode = "";
            $factorAppend->DaryaftiInfo->HavaleNum = $order_id;
            $factorAppend->DaryaftiInfo->HavalePrice = (($order->get_total()==0)?1:$order->get_total());
            $factorAppend->DaryaftiInfo->DepC = 1;
            $factorAppend->DaryaftiInfo->KCode = 1;
 
//            $factorAppend->RizEzafatKosoorat = array();
//            $rizEzafat = new RizEzafatKosooratClass();
//            
//            $rizEzafat->Ft = 1;
//            $rizEzafat->BedBes = "";
//            $rizEzafat->SatrNum = "";
//            $rizEzafat->EzafKosoorCode = "";
//            $rizEzafat->Darsad = "";
//            $rizEzafat->Mablagh = "";
//            $rizEzafat->MabKol = "";
//            
//            $factorAppend->RizEzafatKosoorat[] = $rizEzafat;
            
            $myT = new TahlilApi();
            $myT->UpdateOrder($order_id, json_encode($factorAppend,JSON_UNESCAPED_UNICODE));
            
            
//            echo $data['id']."&nbsp;&nbsp;";
//            echo $data['parent_id']."&nbsp;&nbsp;";
//            echo $data['status']."&nbsp;&nbsp;";
//            echo $data['currency']."&nbsp;&nbsp;";
//            echo $data['version']."&nbsp;&nbsp;";
//            echo $data['payment_method']."&nbsp;&nbsp;";
//            echo $data['payment_method_title']."&nbsp;&nbsp;";
//            echo $data['payment_method']."&nbsp;&nbsp;";
//            echo $data['payment_method']."&nbsp;&nbsp;";
//
//// get formatted date using the method date()
//            echo $data['date_created']->date('Y-m-d H:i:s')."&nbsp;&nbsp;";
//            echo $data['date_modified']->date('Y-m-d H:i:s')."&nbsp;&nbsp;";
//
//// get the timestamp through the method getTimestamp()
//            echo $data['date_created']->getTimestamp()."&nbsp;&nbsp;";
//            echo $data['date_modified']->getTimestamp()."&nbsp;&nbsp;";
//
//// more data
//
//            echo $data['discount_total']."&nbsp;&nbsp;";
//            echo $data['discount_tax']."&nbsp;&nbsp;";
//            echo $data['shipping_total']."&nbsp;&nbsp;";
//            echo $data['shipping_tax']."&nbsp;&nbsp;";
//            echo $data['cart_tax']."&nbsp;&nbsp;";
//            echo $data['total_tax']."&nbsp;&nbsp;";
//            echo $data['customer_id']."&nbsp;&nbsp;";
//// billing - account statement
//
//            echo $data['billing']['first_name']."&nbsp;&nbsp;";
//            echo $data['billing']['last_name']."&nbsp;&nbsp;";
//            echo $data['billing']['company']."&nbsp;&nbsp;";
//            echo $data['billing']['address_1']."&nbsp;&nbsp;";
//            echo $data['billing']['address_2']."&nbsp;&nbsp;";
//            echo $data['billing']['city']."&nbsp;&nbsp;";
//            echo $data['billing']['state']."&nbsp;&nbsp;";
//            echo $data['billing']['postcode']."&nbsp;&nbsp;";
//            echo $data['billing']['country']."&nbsp;&nbsp;";
//            echo $data['billing']['email']."&nbsp;&nbsp;";
//            echo $data['billing']['phone']."&nbsp;&nbsp;";
//
//// shipping
//
//            echo $data['shipping']['first_name']."&nbsp;&nbsp;";
//            echo $data['shipping']['last_name']."&nbsp;&nbsp;";
//            echo $data['shipping']['company']."&nbsp;&nbsp;";
//            echo $data['shipping']['address_1']."&nbsp;&nbsp;";
//            echo $data['shipping']['address_2']."&nbsp;&nbsp;";
//            echo $data['shipping']['city']."&nbsp;&nbsp;";
//            echo $data['shipping']['state']."&nbsp;&nbsp;";
//            echo $data['shipping']['postcode']."&nbsp;&nbsp;";
//            echo $data['shipping']['country']."&nbsp;&nbsp;";
        }

        // add custom interval
        function cron_add_minute($schedules) {
            // Adds once every minute to the existing schedules.
            $schedules['threehours'] = array(
                'interval' => 60 * intval(get_option('tahlil_api_interval_update')), //Hours
                //'interval' =>  60 * 60 * intval(get_option('tahlil_api_interval_update')), //Hours
                'display' => __('Once in three hours')
            );
            return $schedules;
        }

        add_filter('cron_schedules', 'cron_add_minute');

        
        
        add_action('template_redirect','check_if_logged_in');
        function check_if_logged_in()
        {
            $pageid = 9; // your checkout page id
            if(is_user_logged_in() && is_page($pageid))
            {
                //$url = add_query_arg(
                //    'redirect_to',
                //    get_permalink($pagid),
                //    site_url('/wp-login.php') // your my acount url
                //);
                //wp_redirect($url);
                //exit;
            }
        }

        // create a scheduled event (if it does not exist already)
        function cronstarter_activation() {
            if (!wp_next_scheduled('mycronjob')) {
                wp_schedule_event(time(), 'threehours', 'mycronjob');
            }
        }

        // and make sure it's called whenever WordPress loads
        add_action('wp', 'cronstarter_activation');

        // here's the function we'd like to call with our cron job
        function my_repeat_function() {
            global $wpdb;
            // do here what needs to be done automatically as per your schedule
            // in this example we're sending an email
            $myT = new TahlilApi();
            $myT->SendOrders();
            $m = $myT->setProducts();
            $myT->update_persons();
            $date = jalaliDate();
            $sql = " INSERT INTO " . $wpdb->prefix . TahlilApi::TableName . " (log_desc,log_date) values ('$m', '$date')";

            $wpdb->query($sql);
        }

        // hook that function onto our scheduled event:
        add_action('mycronjob', 'my_repeat_function');

        // unschedule event upon plugin deactivation
        function cronstarter_deactivate() {
            // find out when the last event was scheduled
            $timestamp = wp_next_scheduled('mycronjob');
            // unschedule previous event if any
            wp_unschedule_event($timestamp, 'mycronjob');
        }

        register_deactivation_hook(__FILE__, 'cronstarter_deactivate');
    });
}
