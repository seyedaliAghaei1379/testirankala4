<?php 
session_set_cookie_params(5600, '/', $_SERVER['HTTP_HOST'], true, true);
session_start();
?>
<?php 
/*ob_start("minifier"); 
function minifier($code) { 
    $search = array( 
          
        // Remove whitespaces after tags 
        '/\>[^\S ]+/s', 
          
        // Remove whitespaces before tags 
        '/[^\S ]+\</s', 
    ); 
    $replace = array('>', '<', '\\1'); 
    $code = preg_replace($search, $replace, $code); 
    return $code; 
} */
?> 
<!DOCTYPE html>
<html class=" js" xmlns="http://www.w3.org/1999/xhtml" dir="rtl" lang="fa" xml:lang="fa">
<?php
/**
 * Created by PhpStorm.
 * User: moradi
 * Date: 5/30/19
 * Time: 4:57 PM
 */

    include_once("classes/class.cnfg.php");

    $conf = new config();
    $BaseRoot = $conf->BaseRoot;
    $BaseRoot2 = $conf->BaseRoot2;
    $UserPanelUrl = $conf->UserPanelUrl;
    $AdminUrl = $conf->AdminUrl;
    include_once($conf->BaseRoot . '/classes/class.main.php');
    include_once($conf->BaseRoot . '/classes/class.access.php');

    $ths = new main();
    $access = new access();

    include_once($conf->BaseRoot.'classes/class.libs_parent.php');



    date_default_timezone_set('Asia/Tehran');

    $ths->CheckBlockIP();


    $PID = (isset($_REQUEST['pid']) && $_REQUEST['pid'] <= 1000) ? $_REQUEST['pid'] : 1;
    $PageInfo = $access->GetAccess($PID);

    if(!isset($_SESSION['_Lang_'])){
        $_SESSION['_Lang_'] = 1;
    }


    if ($PageInfo) {
        $MyPath = $BaseRoot . $PageInfo['PageUrl'] . ".php";
        if (!is_file($MyPath)) {
            $PageInfo = false;
        }
    }

    if (!$PageInfo) {
        $PageInfo = $access->GetAccess(45);
        $MyPath = $BaseRoot . $PageInfo['PageUrl'] . ".php";

        $ths->CheckNotFoundPage();

        $PID = 45;
    }

    $Cnfg = $ths->getSetting();

    include_once($conf->BaseRoot . $conf->UserPanelUrl . "/Common/Amar.php");

    if ($PID == 5) {
        include_once($conf->BaseRoot . $conf->UserPanelUrl . '/Product/ViewUp.php');
    }

    $IsCatBrand = false;
    if ($PID == 4) {
        include_once($conf->BaseRoot.'/classes/libs/class.category_brand.php');
        $CatBrandClass = new category_brand();

        if(isset($_REQUEST['BrandID']) && $_REQUEST['BrandID'] && isset($_REQUEST['CatID']) && $_REQUEST['CatID']){
            $CatBrnd = [];
            $CatBrnd[] = ['cat_id', $_REQUEST['CatID']];
            $CatBrnd[] = ['brand_id', $_REQUEST['BrandID']];
            $CatBrnd[] = ['display', 1];
            $CatBrnd[] = ['deleted', 0];

            $CatBrandRow_ = $CatBrandClass->get_all($CatBrnd);
            if($CatBrandRow_){
                $IsCatBrand = true;
                $CatBrandRow = $CatBrandRow_[0];
            }
        }
        
    
    }
?>


<head>
     <?php
        $MyTitle = $PageInfo['Title'];
        

        $_REQUEST['CurrPage'] = (isset($_REQUEST['CurrPage']) ? (int)$ths->MakeSecurParam($_REQUEST['CurrPage']) : '');
        $_REQUEST['CatID'] = (isset($_REQUEST['CatID']) ? (int)$ths->MakeSecurParam($_REQUEST['CatID']) : '');
        $_REQUEST['MyID'] = (isset($_REQUEST['MyID']) ? (int)$ths->MakeSecurParam($_REQUEST['MyID']) : '');
        $_REQUEST['search_filter'] = (isset($_REQUEST['search_filter']) ? $ths->MakeSecurParam($_REQUEST['search_filter'], true) : '');

        switch($PID){
            case 4 :    $Pg = (isset($_REQUEST['CurrPage']) ? $_REQUEST['CurrPage'] : 1);
                        if(isset($_REQUEST['CatID']) && $_REQUEST['CatID']>0){
                             
                           

                            include_once($conf->BaseRoot.'/classes/libs/class.category.php');
                            $CatClass = new category();

                            $CatID = $_REQUEST['CatID'];
                              $catinfo = $CatClass->get_by_id($CatID, ['title', 'title_seo', 'title1', 'title2', 'comment', 'descriptions', 'meta_description']);
        
                             $titseo = $catinfo->title_seo;
                             
                            //$CatTit = $CatClass->get_title_by_id2($CatID,'');
                            $CatTit = $CatClass->get_title_by_id($CatID);
                            
                            if($Pg == 1){
                                if($titseo != ""){ $MyTitle = $titseo;}else{$MyTitle =  ' قیمت، مشخصات و خرید  ' . $CatTit  ;}
                            }else{
                                if($titseo != ""){
                                    $MyTitle = $titseo ;
                                    
                                }else{
                                    $MyTitle = ' - '.$CatTit.' قیمت، مشخصات و خرید  '.$Pg;
                                }
                            }

                            $ReplaceArr = [$CatID, /*$Pg*/ 1, $CatTit];
                            $ItemArr = ['#id#', '#pg#', '#title#'];

                            if(isset($_REQUEST['BrandID']) && $_REQUEST['BrandID']){

                                include_once($conf->BaseRoot.'/classes/libs/class.category_brand.php');
                                $CatBrandClass = new category_brand();

                                $CatTit0 = $CatBrandClass->get_all([['cat_id', $CatID], ['brand_id', $_REQUEST['BrandID']], ['display', 1], ['deleted', 0]]);
                                if($CatTit0){
                                    $PageInfo['SeoUrl'] = 'category/#id#/brand/#id2#/#pg#/#title#';
                                    $CatTit = $CatTit0[0]->title_en;
                                    $ItemArr[] = '#id2#';
                                    //$ReplaceArr[] = $_REQUEST['BrandID'];
                                    $ReplaceArr = [$CatID, /*$Pg*/ 1, $CatTit, $_REQUEST['BrandID']];
                                    
                                    $MyTitle = $CatTit0[0]->title_seo.($Pg == 1 ? '' : ' - صفحه '.$Pg);
                                }
                            }
                            $PageInfo['SeoUrl'] = $ths->UrlFriendly(str_replace($ItemArr, $ReplaceArr, $PageInfo['SeoUrl']));
                            
                            
                        }else{
                            if($Pg == 1){
                                #$PageInfo['SeoUrl'] = 'category/لیست-محصولات';
                                $PageInfo['SeoUrl'] = 'category';
                            }else{
                                #$PageInfo['SeoUrl'] = 'category/0/'.$Pg.'/لیست-محصولات';
                                $PageInfo['SeoUrl'] = 'category/0/'.$Pg;
                            }
                            $MyTitle .= ' صفحه '.$Pg;
                        }
                        break;

            case 5 :    global $n;

                        include_once($conf->BaseRoot.'/classes/libs/class.category.php');
                        $CatClass = new category();

                        include_once($conf->BaseRoot.'/classes/libs/class.brand.php');
                        $BrandClass = new brand();

                        $PageInfo['SeoUrl'] = $ths->UrlFriendly(str_replace( ['#id#', '#title#'], [$_REQUEST['MyID'], $n->title], $PageInfo['SeoUrl']));
                        $CatTit = $CatClass->get_title_by_id2($n->cat_id, '');
                        $BrandTit = $BrandClass->get_title_by_id($n->brand_id);
                        $MyTitle = $CatTit.' - برند '.$BrandTit.' - '.$n->title;
                        $MyTitle = 'قیمت، مشخصات و خرید '.$n->title.' '.$n->model;
                        break;

            case 7 :
            case 8 :
            case 6 :    $Pg = (isset($_REQUEST['CurrPage']) ? $_REQUEST['CurrPage'] : 1);
                        $Srch = (isset($_REQUEST['search_filter']) ? $_REQUEST['search_filter'] : '');
                        $PageInfo['SeoUrl'] = $ths->UrlFriendly(str_replace( ['#pg#/', '#srch#'], [/*$Pg*/'', $Srch], $PageInfo['SeoUrl']));
                        
                        
global $ths, $conf;

    include_once($conf->BaseRoot.'/classes/libs/class.brand.php');
    $BrandClass = new brand();
    
     
         $_SESSION['_Lang_'] = 1;
    $MyFilters = [];
     
     
        if(!isset($_SESSION['_Lang_'])){
        $_SESSION['_Lang_'] = 1;
    }

    $CondArr[] = ['display', 1];
    $CondArr[] = ['deleted', 0];
    $CondArr[] = ['lang_id', $_SESSION['_Lang_']];
    $AllBrand = $BrandClass->get_all($CondArr, [], ['ordr', 'desc'], [0, 16]);

    include_once($conf->BaseRoot.'/classes/libs/class.product.php');
    $ProductClass = new product();
    
    $AllResult = $ProductClass->get_all($CondArr, ['product`.`product_id', 'brand_id']/* #1#, [], [], $GroupBy, $Tbl*/);
    
    $BrandStr = '';
    if($AllResult){
        $BrandArr = [];
        #$MyIDs = [];
        foreach($AllResult as $res){
            $BrandArr[] = $res->brand_id;
            #$MyIDs[] = $res->product_id;
        }
        $BrandArr = array_unique($BrandArr);

        $MyBrandTitle = [];
        $MyBrand = $BrandClass->get_all([['brand_id', $BrandArr, 'in'], ['lang_id', $_SESSION['_Lang_']], ['deleted', 0]], ['brand_id', 'title']);
        if($MyBrand){
            foreach($MyBrand as $bb){
                $MyBrandTitle[$bb->brand_id] = $bb->title;
            }
        }


        $brandArr = [];
        $SelBrand = [];
        if(isset($_REQUEST['BrandID'])){
            $brandArr = explode('-', (int)$_REQUEST['BrandID']);
        }
        foreach($BrandArr as $brnd){
            $IsSel = in_array($brnd, $brandArr) ? true  : false;

            if($IsSel){
                $SelBrand[] = (isset($MyBrandTitle[$brnd]) ? $MyBrandTitle[$brnd] : 0);
            }

        }
    }

    if(isset($_REQUEST['BrandID']) && (int)$_REQUEST['BrandID']){
        $CondArr[] = ['brand_id', $_REQUEST['BrandID']];


        if(isset($SelBrand) && is_array($SelBrand)){
            $MyFilters[] = ['برند', implode(' - ', $SelBrand), 'BrandID'];
        }
    }
     foreach($MyFilters as $fname){
         $brandname = $fname[1];

                        $MyTitle = ' قیمت، مشخصات و خرید محصولات برند  '. $brandname ;
                        break;
        } }

    ?>

    <title>
       <?= ($PID == 1  ? 'ایران کالا | فروشگاه آنلاین لوازم خانگی' : $MyTitle.' - ') . ($PID == 5 ? 'ایران کالا' : ($PID == 1 ? '' : $Cnfg['SiteTitle']) )?>
    </title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="content-language" content="fa"/>
    <meta http-equiv="Pragma" content="no-cache">
    <meta http-equiv="Cache-Control" content="no-cache" />
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <meta name="HandheldFriendly" content="true"/>
    <meta name="format-detection" content="telephone=no">
    <meta name="keywords" content="<?= $Cnfg['SiteKeyword'] ?>">
    <meta name="description" content="<?= (($IsCatBrand && isset($CatBrandRow)) ? $CatBrandRow->meta_description : $Cnfg['SiteDescription']) ?>">
    <meta name="robots" content="index, follow"/>
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-TileImage" content="/ms-icon-144x144.png">
    <meta name="theme-color" content="#262626">
    <meta name="msapplication-navbutton-color" content=" #1c1c21">
    <meta name="apple-mobile-web-app-status-bar-style" content="#fb3449">
    <meta name="msvalidate.01" content="57B330F869ADC5937921D8A2C9376225" />
    
    <?php if($PID == 5){?>
  <!-- product-->
 
<meta property="og:type" content="product">
<meta property="og:title" content="<?=$n->title.' '.$n->model?>">
<meta property="og:url" content="<?=$conf->BaseRoot2.'product/'.$n->product_id.'/'.trim($ths->UrlFriendly($n->title))?>">
<meta property="og:description" content="قیمت و مشخصات و خرید <?=$n->title.' '.$n->model?> از سایت ایران کالا">
<meta property="og:image" content="<?php $_img=$FilesClass->get_all(1, $n->product_id); echo $_img[0]['path2']; ?>">
<meta property="og:image:width" content="700"/>
<meta property="og:image:height" content="700"/>
<meta property="product:condition" content="new">
<meta property="product:availability" content="<?=($MyProductPrice ? 'in' : 'out of')?> stock">
<meta property="product:price:amount" content="<?=($MyProductPrice * 10)?>">
<meta property="product:price:currency" content="IRR">
<?php if ($PID == 5) { ?>

    <meta name="product_price" content="<?=$MyProductPrice?>">
    <meta name="product_old_price" content="<?=round(($MyProductPrice * 100) / 82)?>">

    
<?php }?>

  <!-- product-->
<?php }?>

    <link rel="shortcut icon" href="<?=$conf->BaseRoot2?>favicon.ico" type="image/icon">
    <link rel="icon" type="image/png" sizes="192x192" href="<?=$conf->BaseRoot2?>Files/images/desktop/192.png">
    <link rel="icon" type="image/png" sizes="32x32" href="<?=$conf->BaseRoot2?>Files/images/desktop/32.png">
    <link rel="icon" type="image/png" sizes="96x96" href="<?=$conf->BaseRoot2?>Files/images/desktop/96.png">
    <link rel="icon" type="image/png" sizes="16x16" href="<?=$conf->BaseRoot2?>Files/images/desktop/16.png">
    <meta name="msapplication-TileImage" content="<?=$conf->BaseRoot2?>Files/images/desktop/192.png">
    <link rel="manifest" href="/manifest.json?v=1.4">

    <!-- css by Dr.Hossein Moradi hssin.ir -->
<!--    <link rel="stylesheet" href="<?= $conf->BaseRoot2 ?>Files/css/cart.css">-->
    <link rel="stylesheet" href="<?= $conf->BaseRoot2 ?>Files/vendor/bootstrap/css/bootstrap.css">
    <link rel="stylesheet" href="<?= $conf->BaseRoot2 ?>Files/css/all.min.css?seed=<?=date("Y-m-d-H")?>">
    <?php if($PID == 12){?>
        <link rel="stylesheet" href="<?= $conf->BaseRoot2 ?>Files/css/dashboard.css?seed=1400-03-25">
        <?php } ?>
    <link rel="stylesheet" href="<?= $conf->BaseRoot2 ?>Files/css/style.header-classic-variant-one.css" media="(min-width: 1200px)">
    <link rel="stylesheet" href="<?= $conf->BaseRoot2 ?>Files/css/style.mobile-header-variant-one.css" media="(max-width: 1199px)">
  
    

    


    <!-- font - fontawesome -->
    <!--<link rel="stylesheet" href="<?= $conf->BaseRoot2 ?>Files/vendor/fontawesome/css/all.min.css">-->
<?php if($PID == 5){?>
    <!--<link rel="stylesheet" href="<?= $conf->BaseRoot2 ?>Files/css/easyzoom.css">-->

<?php } ?>

  <script src="<?=$conf->BaseRoot2?>Files/js/jquery-3.5.1.min.js"></script>
    <script>
$(document).ready(function(){
    $('#notlogin').delay(5000).fadeOut();
});
    </script>


  <!-- PureCookie popup box -->
<!-- <?php #if($PID == 1 && $PopUp){?>
    <script>
        var MyPopup = '<?='';//$PopUp?>';
    </script>
    <script defer src="<?=$conf->BaseRoot2?>Files/js/purecookie.js?seed=1399-05-28" ></script> -->
<!-- PureCookie popup box -->
<?php #}?>
<!---start GOFTINO code--->


   
<?php if($PID == 5){?>
    <link rel="canonical" href="<?=$conf->BaseRoot2.'product/'.$_REQUEST['MyID'].'/'.trim($ths->UrlFriendly($n->title))?>">
<?php } ?>


        <link rel="manifest" href="/manifest.json">

       <script> !function (t, e, n) { t.yektanetAnalyticsObject = n, t[n] = t[n] || function () { t[n].q.push(arguments) }, t[n].q = t[n].q || []; var a = new Date, r = a.getFullYear().toString() + "0" + a.getMonth() + "0" + a.getDate() + "0" + a.getHours(), c = e.getElementsByTagName("script")[0], s = e.createElement("script"); s.id = "ua-script-OssDdIqu"; s.dataset.analyticsobject = n; s.async = 1; s.type = "text/javascript"; s.src = "https://cdn.yektanet.com/rg_woebegone/scripts_v3/OssDdIqu/rg.complete.js?v=" + r, c.parentNode.insertBefore(s, c) }(window, document, "yektanet"); </script> 
<!---start GOFTINO code--->
<script type="text/javascript">
  !function(){var i="c4kX1N",a=window,d=document;function g(){var g=d.createElement("script"),s="https://www.goftino.com/widget/"+i,l=localStorage.getItem("goftino_"+i);g.async=!0,g.src=l?s+"?o="+l:s;d.getElementsByTagName("head")[0].appendChild(g);}"complete"===d.readyState?g():a.attachEvent?a.attachEvent("onload",g):a.addEventListener("load",g,!1);}();
</script>
<!---end GOFTINO code--->
</head>

<body class="toppad">


<!-- site -->
<div class="site">

    <!-- site__mobile-header 37-->
    <?php if($PID != 37){?>
    <?= $ths->LoadPage($conf->UserPanelUrl . 'Common/Header') ?>
    <?php } ?>
    <!-- header -->

    <!-- site__body -->
    <div class="site__body sub-nav">

        <?php if($PID != 1 && $PID != 45){?>
            <?= $ths->LoadPage($conf->UserPanelUrl . 'Common/BreadCrumb') ?>
        <?php }?>


        <?php
            if($PID != 1){
                echo $ths->LoadPage($PageInfo['PageUrl']);
            }else{
                $CacheName = 'Home/Main';
                $CacheFile = $ths->is_cache($CacheName);
                if($CacheFile){
                    echo $CacheFile;
                }else{
                    ob_start();
        ?>
                    <div class="block-space block-space--layout--divider-xs"></div>

                    <?= $ths->LoadPage($conf->UserPanelUrl . 'Home/SlideShow') ?>
                    
                    <?= $ths->LoadPage($conf->UserPanelUrl . 'Home/Service') ?>

                    <?= $ths->LoadPage($conf->UserPanelUrl . 'Home/Special') ?>
                    
                    <!-- 1 -->

                    <div class="block-space block-space--layout--divider-nl w576none"></div>

                    <?= $ths->LoadPage($conf->UserPanelUrl . 'Home/Promotion') ?>
                    
                    
           
       
                    <?php
                        $CatBox = [/*169, 165,*/304, 73, 143];
                        foreach($CatBox as $c){
                            $_REQUEST['MyCatID'] = $c;
            
                            
                            
                                 include($conf->BaseRoot.$conf->UserPanelUrl . 'Home/CatBox.php');
                                
                        }
                        ?>
                        
                        <!--<?= $ths->LoadPage($conf->UserPanelUrl . 'Home/Banner2.php') ?>-->
                        
                        <!-- 2 -->

                    <?= $ths->LoadPage($conf->UserPanelUrl . 'Home/Banner') ?>

                    <div class="block-space block-space--layout--divider-nl w576none"></div>

                    <?= $ths->LoadPage($conf->UserPanelUrl . 'Home/NewProduct') ?><!-- 3 -->
                    <div class="block-space block-space--layout--divider-nl w576none"></div>

                    <?= $ths->LoadPage($conf->UserPanelUrl . 'Home/BestCat') ?>
                    
                    <div class="block-space block-space--layout--divider-nl w576none"></div>

                    <div class="block-space block-space--layout--divider-nl"></div>

                    <?= $ths->LoadPage($conf->UserPanelUrl . 'Home/Brands') ?>

                    <div class="block-space block-space--layout--divider-lg"></div>

        <?php
                    $ths->save_cache($CacheName, ob_get_contents());
                    ob_end_flush();
                }
            }
        ?>


    </div>
    <!-- site__body / end -->
    
    <!-- site__footer -->
    <?php if($PID != 37){?>
    <?= $ths->LoadPage($conf->UserPanelUrl . 'Common/Footer'.($PID == 1 ? '_Home' : '')) ?>
    <?php } ?>
    <!-- site__footer / end -->
    
</div>
<!-- site / end -->

<!-- mobile-menu -->
    <?= $ths->LoadPage($conf->UserPanelUrl . 'Common/MobileMenu') ?>
<!-- mobile-menu / end -->


<!-- scripts -->


<?php if($PID == 5){?>
    <!-- photoswipe -->
    <div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">  <div class="pswp__bg"></div><div class="pswp__scroll-wrap"><div class="pswp__container"><div class="pswp__item"></div><div class="pswp__item"></div><div class="pswp__item"></div></div><div class="pswp__ui pswp__ui--hidden"><div class="pswp__top-bar"><div class="pswp__counter"></div><button class="pswp__button pswp__button--close" title="Close (Esc)"></button><!--<button class="pswp__button pswp__button&#45;&#45;share" title="Share"></button>--> <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button> <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button><div class="pswp__preloader"><div class="pswp__preloader__icn"><div class="pswp__preloader__cut"><div class="pswp__preloader__donut"></div></div></div></div></div><div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap"><div class="pswp__share-tooltip"></div></div><button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)"></button> <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)"></button><div class="pswp__caption"><div class="pswp__caption__center"></div></div></div></div></div>
    <!-- photoswipe / end -->
<?php }?>

<script>
    var BaseRoot2 = '<?=$conf->BaseRoot2?>';
    var MyLang = 1;
</script>


<!--<script src="<?=$conf->BaseRoot2?>Files/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>-->
<script src="<?=$conf->BaseRoot2?>Files/vendor/owl-carousel/owl.carousel.min.js"></script>
<script src="<?=$conf->BaseRoot2?>Files/vendor/nouislider/nouislider.min.js"></script>
<script src="<?=$conf->BaseRoot2?>Files/vendor/photoswipe/photoswipe.min.js"></script>
<script src="<?=$conf->BaseRoot2?>Files/vendor/photoswipe/photoswipe-ui-default.min.js"></script>
<script src="<?=$conf->BaseRoot2?>Files/vendor/select2/js/select2.min.js"></script>
<script src="<?=$conf->BaseRoot2?>Files/js/number.js?seed=1400-04-29"></script>
<script src="<?=$conf->BaseRoot2?>Files/js/main.js?seed=1400-08-12"></script>
<script src="<?=$conf->BaseRoot2?>Files/js/util.js"></script>
<script src="<?=$conf->BaseRoot2?>Files/js/lazyload.min.js"></script>
<script src="<?=$conf->BaseRoot2?>Files/js/main1.js?seed=1402-04-29"></script>

<?php if ($PID == 5) { ?>
<script src="<?=$conf->BaseRoot2?>Files/js/util1ee8.js?v=78"></script>
<script src="<?=$conf->BaseRoot2?>Files/js/rating.min665c.js?v=39"></script>

<?php }?>
    <script>
      (function () {
        function logElementEvent(eventName, element) {
          console.log(Date.now(), eventName, element.getAttribute("data-src"));
        }

        var callback_enter = function (element) {
          logElementEvent("🔑 ENTERED", element);
        };
        var callback_exit = function (element) {
          logElementEvent("🚪 EXITED", element);
        };
        var callback_loading = function (element) {
          logElementEvent("⌚ LOADING", element);
        };
        var callback_loaded = function (element) {
          logElementEvent("👍 LOADED", element);
        };
        var callback_error = function (element) {
          logElementEvent("💀 ERROR", element);
          element.src =
            "https://source.unsplash.com/random/440x560/?text=Error+Placeholder";
        };
        var callback_finish = function () {
          logElementEvent("✔️ FINISHED", document.documentElement);
        };
        var callback_cancel = function (element) {
          logElementEvent("🔥 CANCEL", element);
        };

        var ll = new LazyLoad({
          elements_selector: "[loading=lazy]",
          use_native: true,
          // Assign the callbacks defined above
          callback_enter: callback_enter,
          callback_exit: callback_exit,
          callback_cancel: callback_cancel,
          callback_loading: callback_loading,
          callback_loaded: callback_loaded,
          callback_error: callback_error,
          callback_finish: callback_finish
        });
      })();
    </script>


<?php if(in_array($PID, [1, 4, 6, 7, 8, 42])){?>
    <script src="<?=$conf->BaseRoot2?>Files/js/common.js?seed=1399-08-10"></script>
<?php }?>



<?php
    if($PID == 1){
        $CatBox = [1, 11];
?>


<?php }?>


<script>
function loading(MyID) {
    
    var button = document.getElementById('send_' + MyID);
    
    button.blur();

    button.classList.add("is-loading");

    setTimeout(() => done(MyID), 900);
}

function done(MyID) {
    var button = document.getElementById('send_' + MyID);
    button.classList.remove("is-loading");
    button.classList.add("is-done");

    setTimeout(() => reset(MyID), 800);
}

function reset(MyID) {
    var button = document.getElementById('send_' + MyID);
    button.classList.remove("is-done");
}

</script>
<?php if(in_array($PID, [4, 6, 7, 8, 42])){?>
<script>
    function addToCart2(prid){

    var company_id = $('#MyCompany').val();
    
    $.post(BaseRoot2 + 'order_add_to_basket',
        {ProdID:prid, Prop:'', ChangeCount:'1', CompanyID:company_id},
        function(data){
            
            var j = $.parseJSON(data);
            if(j.msg != ''){
                alert(j.msg);
            }else{
                $('.indicator__counter').html(j.total_count);
                $('.mobile-indicator__counter').html(j.total_count);
                $("html, body").animate({ scrollTop: 0 }, 500);
            }
        }
    );
}
</script>
<?php }?>
<?php if(in_array($PID, [4, 6, 7, 8, 42, 14])){?>
    <script src="<?=$conf->BaseRoot2?>Files/js/product-list.js?seed=1399-09-09"></script>

    <script>
        LoadSideFilter21();
        LoadProductList21();
        LoadLatest21();
    </script>
<?php }?>

<?php if($PID == 5){?>
    <script>
        var MyID = '<?=(isset($n) ? $n->product_id : 0)?>';
        var MyPersonID = '<?=(isset($_SESSION['_LoginUserID_']) ? $_SESSION['_LoginUserID_'] : 0)?>';
        var IsInCompareList = '<?=(int)(isset($_SESSION['CompareIDs']) && in_array($n->product_id, $_SESSION['CompareIDs']))?>';
        var MyLang = 1;
        var Discount = '<?=$Cnfg['PriceOffPercent']?>';
    </script>
<script src="<?=$conf->BaseRoot2?>Files/js/product-view.js?seed=1402-10-15"></script>


    <script>
        LoadPrice();
        LoadCompany();
    </script>
    
<?php
include_once($conf->BaseRoot.'classes/libs/class.product_schema.php');
    $Prodschema = new product_schema();
    $FilterArrsh = [];
    $FilterArrsh[] = ['deleted', 0];
    $FilterArrsh[] = ['display', 1];

$shemas = $Prodschema->get_all($FilterArrsh);
if($shemas){
    foreach($shemas as $sh){
        if($sh->type == 3){
            echo $sh->schma;
        }
    }
}

}
if($PID == 4){
   include_once($conf->BaseRoot.'classes/libs/class.product_schema.php');
    $Prodschema = new product_schema();
    $FilterArrsh = [];
    $FilterArrsh[] = ['deleted', 0];
    $FilterArrsh[] = ['display', 1];

$shemas = $Prodschema->get_all($FilterArrsh);
if($shemas){
    foreach($shemas as $sh){
        if(isset($_REQUEST['BrandID']) && $_REQUEST['BrandID'] && isset($_REQUEST['CatID']) && $_REQUEST['CatID']){
        if($sh->type == 4){
            echo $sh->schma;
        }
    }elseif(isset($_REQUEST['CatID']) && $_REQUEST['CatID'] && !(isset($_REQUEST['BrandID']) && $_REQUEST['BrandID'])){
        if($sh->type == 1 && $sh->rel_id == $_REQUEST['CatID']){
            echo $sh->schma;
        }
    }elseif($PID == 7){
        if($sh->type == 2 && $sh->rel_id == $_REQUEST['BrandID']){
            echo $sh->schma;
        }
    }
    }
} 
}

?>

<?php if($PID == 18){?>
    <script>
        //LoadFactor();
    </script>
<?php }?>

<?php if($PID == 28){?>
    <script src="<?=$conf->BaseRoot2?>Files/js/compare.js?seed=1399-08-10"></script>
<?php }?>

<?php if($PID == 37){?>
    <script src="<?=$conf->BaseRoot2?>Files/js/checkout.js?seed=1402-12-25"></script>
<?php }?>

<?php if($PID == 13){?>
    <script src="<?=$conf->BaseRoot2?>Files/js/profile.js?seed=1399-09-16"></script>
<?php }?>


<?php
       


        if($PID == 1){
    ?>
<!--    <link rel="stylesheet" type="text/css" href="<?=$conf->BaseRoot2?>Files/css/purecookie.css" />-->

<?= $ths->LoadPage($conf->UserPanelUrl . 'Home/PopUp') ?>




    <script>
        
        
        (function(){"use strict";var cookieAlert=document.querySelector(".cookiealert");var acceptCookies=document.querySelector(".acceptcookies");cookieAlert.offsetHeight;if(!getCookie("acceptCookies")){cookieAlert.classList.add("show");}
acceptCookies.addEventListener("click",function(){setCookie("acceptCookies",true,60);cookieAlert.classList.remove("show");});})();function setCookie(cname,cvalue,exdays){var d=new Date();d.setTime(d.getTime()+(exdays*24*60*60*1000));var expires="expires="+d.toUTCString();document.cookie=cname+"="+cvalue+";"+expires+";path=/";}
function getCookie(cname){var name=cname+"=";var decodedCookie=decodeURIComponent(document.cookie);var ca=decodedCookie.split(';');for(var i=0;i<ca.length;i++){var c=ca[i];while(c.charAt(0)===' '){c=c.substring(1);}
if(c.indexOf(name)===0){return c.substring(name.length,c.length);}}
return "";}
    </script>
<!--    <script defer src="<?=$conf->BaseRoot2?>Files/js/purecookie.js?seed=1399-05-28" ></script>-->
    <?php }?>
    
    <script>
        $(".js-cd-add-to-cart").click(function() {
    $(this).addClass("product-card__action--loading");
    that = this
    setTimeout(function() {
        $(that).removeClass('product-card__action--loading');
    }, 600);
    function launch_toast3() {
      document.getElementById("desc").innerHTML = "محصول به سبد خرید شما اضافه شد .";
  var x = document.getElementById("toast");
  x.className = "show";
  setTimeout(function () {x.className = x.className.replace("show", "");}, 5000);
}
window.setTimeout(function(){
    $(".js-cd-add-to-cart").addClass("csvg");
        launch_toast3();
    }, 600);
});
    </script>
<div class="notify">
    <svg class="vector-container" viewBox="0 0 25 25" width="25" height="25"><path fill="rgb(76, 175, 80)" d="M12.5 0C5.602 0 0 5.602 0 12.5S5.602 25 12.5 25 25 19.398 25 12.5 19.398 0 12.5 0zm-2.3 18.898l-5.5-5.5 1.8-1.796 3.7 3.699L18.5 7l1.8 1.8zm0 0"></path></svg>
    <span id="notifyType" class="CompareMsg "></span></div>
                                                     <div id="toast"><div id="img"><img class="najva-bell-image" src="data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/PjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgdmlld0JveD0iMCAwIDUzIDUzIiBzdHlsZT0iZW5hYmxlLWJhY2tncm91bmQ6bmV3IDAgMCA1MyA1MzsiIHhtbDpzcGFjZT0icHJlc2VydmUiIHdpZHRoPSI2NHB4IiBoZWlnaHQ9IjY0cHgiPjxwYXRoIHN0eWxlPSJmaWxsOiNFN0VDRUQ7IiBkPSJNMTIuODIxLDQ2LjYzOGMxMC43MDEsMS44NDcsMTYuNjU5LDEuODQ3LDI3LjM2LDBMNDkuNjcxLDQ1bDAsMGMtNC42ODUtNC42NTctNy4zMTctMTAuNDE1LTcuMzE3LTE3ICB2LTljMC4wMzgtNi4wNDctMy45NTctMTAuNDc4LTcuOTQ2LTEyLjMwMWMtNC45OTktMi4yODUtMTAuODE1LTIuMjk0LTE1LjgwNiwwLjAwOEMxNC42NDgsOC41MywxMC4zNjcsMTIuOTU4LDEwLjMyOSwxOXY5ICBjMCw2LjU4NS0yLjMxNSwxMi4zNDMtNywxN2wwLDBMMTIuODIxLDQ2LjYzOHoiLz48cGF0aCBzdHlsZT0iZmlsbDojRkZGRkZGOyIgZD0iTTE1LjMyOSwyMGMtMC4wMDIsMC0wLjAwNCwwLTAuMDA2LDBjLTAuNTUyLTAuMDA0LTAuOTk3LTAuNDU0LTAuOTk0LTEuMDA2ICBjMC4wMy00LjY4MiwzLjc1Mi03LjY0Myw1Ljk0OC04LjY1NGMzLjg0OS0xLjc3NSw4LjU5NC0xLjc3MiwxMi40NjktMC4wMDJjMC41MDIsMC4yMjksMC43MjMsMC44MjIsMC40OTQsMS4zMjUgIGMtMC4yMywwLjUwMi0wLjgyMywwLjcyNC0xLjMyNiwwLjQ5M2MtMy4zNTMtMS41MzMtNy40NjktMS41MzctMTAuNzk5LDBjLTEuNzY3LDAuODE0LTQuNzYyLDMuMTczLTQuNzg1LDYuODUgIEMxNi4zMjYsMTkuNTU3LDE1Ljg3OSwyMCwxNS4zMjksMjB6Ii8+PHBhdGggc3R5bGU9ImZpbGw6I0M3Q0FDNzsiIGQ9Ik0zMC4zMjksNS4zODFWNGMwLTIuMjA5LTEuNzkxLTQtNC00cy00LDEuNzkxLTQsNHYxLjQ1M0MyNC45NTgsNC44NjIsMjcuNjksNC44NDEsMzAuMzI5LDUuMzgxeiIvPjxwYXRoIHN0eWxlPSJmaWxsOiNDN0NBQzc7IiBkPSJNMTguMjM1LDQ3LjQ2YzEuNDQ1LDMuMjY4LDQuNjAyLDUuNTQsOC4yNzcsNS41NGMzLjY3NiwwLDYuODM0LTIuMjczLDguMjc4LTUuNTQzICBDMjguODYyLDQ4LjIwOSwyNC4xNTksNDguMjEsMTguMjM1LDQ3LjQ2eiIvPjxnPjwvZz48Zz48L2c+PGc+PC9nPjxnPjwvZz48Zz48L2c+PGc+PC9nPjxnPjwvZz48Zz48L2c+PGc+PC9nPjxnPjwvZz48Zz48L2c+PGc+PC9nPjxnPjwvZz48Zz48L2c+PGc+PC9nPjwvc3ZnPg=="></div><div id="desc"></div></div>

<?php if($PID == 5){?>
  <!-- product-->
                        <script type="application/ld+json">
                {
    "@context": "https://www.schema.org",
    "@type": "Product",
    "name": "<?=$n->title.' '.$n->model?>",
    "alternateName": "<?=($n->title_en ? $n->title_en : '').' '.($n->model_en ? $n->model_en : '')?>",
    "image": [<?php
                                        if($n->img_id){
                                            $MyImg = $FilesClass->get_all(1, $n->product_id);
                                        }else{
                                            $MyImgUrl = $conf->BaseRoot2.'MyFile/Product/none.jpg';
                                        }


                                        if(isset($MyImg) && is_array($MyImg)){
                                            foreach($MyImg as $imgi=>$img){
                                                $MyImgUrl = PHP_EOL.'"'.dirname($img['path2']).'/'.$img['fileid'].'_'.$img['filename'].'"';
                                                $MyImgUrl2 = dirname($img['path2']).'/'.$img['fileid'].'_thumb_'.$img['filename'];
                                                $arrimg[] = $MyImgUrl;
                                            }
                                            echo implode(",",$arrimg).PHP_EOL;

                                        } ?>],
    "description": "قیمت و مشخصات و خرید <?=$n->title.' '.$n->model?> از سایت ایران کالا",
    "sku": <?=$n->code?>,
    "mpn": <?=$n->code?>,
    "aggregateRating": {
        "@type": "AggregateRating",
        "ratingValue": <?=($n->score ? round($n->score) : 5)?>,
        "reviewCount": <?=($n->score_person ? $n->score_person : 1)?>,
        "bestRating": 10,
        "worstRating": 0
    },
    "brand": {
        "@type": "Thing",
        "name": "<?=$BrandClass->get_title_by_id($n->brand_id)?>"
    },
    "offers": {
        "@type": "Offer",
        "url": "<?=$conf->BaseRoot2.'product/'.$n->product_id.'/'.trim($ths->UrlFriendly($n->title))?>",
        "priceCurrency": "IRR",
        "price": "<?=(int)((isset($MyProductPrice) && $MyProductPrice) ? ($MyProductPrice * 10) : '')?>",
        "itemCondition": "https://schema.org/UsedCondition",
        "availability": "https://schema.org/InStock",
        "seller": {
                "@type": "Organization",
                "name": "ایران کالا"
            }
      },
    "review": {
        "@type": "Review",
        "reviewRating": {
            "@type": "Rating",
            "bestRating": 10,
            "ratingValue": <?=round($n->score)?>,
            "worstRating": 0
        }
    }
}
            </script>
             <?php } ?>
             
             <?php
             $r = $_SERVER['REQUEST_URI']; 
$r = explode('/', $r);
$r = array_filter($r);
$r = array_merge($r, array()); 
$r = preg_replace('/\?.*/', '', $r);

$endofurl = (isset($r[0]) ? $r[0] : '');

if($endofurl == "search"){
             ?>
             
                    <script type="application/ld+json">
                {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "url": "https://www.irankala.ir",
    "potentialAction": {
        "@type": "SearchAction",
        "target": "https://www.irankala.ir/search/{search_term_string}",
        "query-input": "required name=search_term_string"
    }
}
            </script>
    
<?php }elseif($PID == 4){ ?>
    
           <script type="application/ld+json">
                {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "url": "https://www.irankala.ir",
    "potentialAction": {
        "@type": "SearchAction", <?php if(isset($_REQUEST['BrandID']) && $_REQUEST['BrandID'] && isset($_REQUEST['CatID']) && $_REQUEST['CatID']){ ?>
        "target": "https://www.irankala.ir/category/<?=$_REQUEST['CatID']?>/brand/<?=(isset($_REQUEST['BrandID']) ? $_REQUEST['BrandID'] : 0)?>/<?=(isset($r[4]) ? $r[4] : 0)?>/{search_term_string}",<?php }elseif(isset($_REQUEST['CatID']) && $_REQUEST['CatID'] && !(isset($_REQUEST['BrandID']) && $_REQUEST['BrandID'])){ ?>"target": "https://www.irankala.ir/category/<?=$_REQUEST['CatID']?>/{search_term_string}",<?php } ?>
        "query-input": "required name=search_term_string"
    }
}
            </script>
    
   <?php }elseif($PID == 7){ ?>
   <script type="application/ld+json">
                {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "url": "https://www.irankala.ir",
    "potentialAction": {
        "@type": "SearchAction",
        "target": "https://www.irankala.ir/brand/<?=$_REQUEST['BrandID']?>/{search_term_string}",
        "query-input": "required name=search_term_string"
    }
}
            </script>
   <?php } ?>
    
</body>
</html>

<?php 
/*ob_end_flush();*/ 
?> 